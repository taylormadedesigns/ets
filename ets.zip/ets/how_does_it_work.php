<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/navbar.php'); ?>
  
<!-- Page Content -->
<!--	<a  name="about"></a>-->
        <div class="video-header">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <!-- 16:9 aspect ratio -->
                    <div class="embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" src="//www.youtube.com/embed/ePbKGoIGAXY?rel=0&autoplay=1"></iframe>
                    </div>
                </div>
            </div>
        </div>
            
    
    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
