<div class="below_nav">
    <div class="container">
        <div class="text-center">
            START ANYTIME!
        </div>    
    </div>
    
</div>
    