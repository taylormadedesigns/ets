<div class="above_nav">
    <div class="container">
        <a class="" href="index.php"><img src="img/tmpt_virtual_training_logo.png"></a>
        <span class="pull-right">
            <a href="clients" class="btn btn-primary">Sign In</a>
            <a class="btn btn-primary">Join Now</a>
        </span>    
    </div>
    
</div>
    