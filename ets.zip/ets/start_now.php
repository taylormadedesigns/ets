<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/navbar.php'); ?>


	<a  name="contact"></a>
    <div class="banner">

        <div class="container">

            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>YOUR ONLINE FITNESS COACH</h2>
                    <h4>Become fitter, stronger and enjoy life!</h4>
                </div>
                <div class="col-lg-8">
                    
                </div>
            </div>

        </div>
        <!-- /.container -->
    </div>
    <!-- /.banner -->

   <!-- Page Content -->
<?php
$subscription = null;
if(isset($_POST['subscription'])){
    $subscription = $_POST['subscription'];
}
?>
<!--	<a  name="about"></a>-->
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-8" style="background-color:#fff; ">
                    <h3 class="section-heading">1. Select your subscription period.</h3>
                    <p class="lead">Your subscription will auto renew. You can cancel auto renewal at any time.</p>
                    <form method="post" action="?q=payment_options">
                        <table class="table table-hover text-center">
                            <tr>
                                <td><input type="radio" class="months" name="subscription" value="3" <?php if ($subscription == 3){echo "checked";}?>></td>
                                <td>3 MONTHS</td>
                                <td>AU$6 / week</td>
                            </tr>
                            <tr>
                                <td><input type="radio" name="subscription" value="6" <?php if ($subscription == 6){echo "checked";}?>></td>
                                <td>6 MONTHS</td>
                                <td>AU$5 / week</td>
                            </tr>
                            <tr>
                                <td><input type="radio" name="subscription" value="12" <?php if ($subscription == 12 || $subscription === null){echo "checked";}?>></td>
                                <td>12 MONTHS</td>
                                <td>AU$4 / week</td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                <?php include('clients/stripe/stripe-pay-now-beginner.php'); ?>
                                <button class="btn btn-primary btn-full-width">Go to payment options</button></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->
    
    
    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
