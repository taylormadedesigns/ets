
	<a  name="about"></a>
    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">What is Taylor Made Virtual Training?</h2>
                    <p class="lead">Taylor Made Virtual Training is a community of coaches and personal trainers that are currently working in the fitness industry at Taylor Made Personal Training Studios, ready to help you transform your life!</p>
                    <p class="lead">Achieve your goals with the latest and most effective training methods by people who are doing this day in and day out.</p>
                    <p class="lead">Virtual Training is a fantastic way to increase your fitness, health and overall lifestyle online. We understand the working demands of todays world and want to make it as easy as possible for you to improve your fitness, nutrition and overall lifestyle habits.</p>
                    <div class="collapse" id="collapse_what_is_tmvt">
                        <div class="lead">
                            <p>If your local Taylor Made Personal Training studio is out of reach for you, then joining our online community and being part of our rapidly growing fitness business is the next best way to start your journey to success.</p>
                            <p>Taylor Made Virtual Training is real people, giving you real advice, with tailored nutritional and training programming for you to complete wherever you have time to do so.</p>
                            <p><b>With Virtual Training you can exercise:</b></p>
                            <ul>
                                <li>Anywhere, anytime!</li>
                                <li>At work</li>
                                <li>At your local gym</li>
                                <li>At a park</li>
                                <li>On holidays</li>
                                <li>At home</li>
                            </ul>
                        </div>
                    </div>
                    <div class="row">
                        <button class="btn btn-primary pull-right" type="button" data-toggle="collapse" data-target="#collapse_what_is_tmvt" aria-expanded="false" aria-controls="collapse_what_is_tmvt">
                          Learn more
                        </button>
                    </div>  
                </div>
                <div class="col-lg-5 col-lg-offset-1 col-sm-6">
                    <img class="img-responsive" src="img/ipad.png" alt="">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->
    <!-- Page Content -->

	<a  name="faqs"></a>
    <div class="content-section-b">

        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Frequently Asked Questions</h2>
<!--                    <p class="lead">Learn by people who have asked before you.</p>-->
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingSix">
                                <h4 class="panel-title">
                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                                        What do I get?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
                                <div class="panel-body">
                                    Not only do you become a part of our fitness community online, you will also speak to a <b>real person</b>.<br><br>
                                    <b>Included in your subscription is:</b>
                                    <ul>
                                        <li>Access to our online members area</li>
                                        <li>Tailored monthly programming for you to complete anywhere, anytime.</li>
                                        <li>Unlimited email support</li>
                                        <li>Monthy nutrition planning. We set your marcronutrient targets (Protein, Carbohydrates & Fats)</li>
                                        <li>Online food tracking</li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <h4 class="panel-title">
                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        How much does it cost?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body">
                                    Our online virtual training programs cost only AUD$29.95 per month.
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingTwo">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Am I locked into a lengthy contract?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                <div class="panel-body">
                                    No, your virtual training plan is a monthly commitment.
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingThree">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        How do I pay?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body">
                                    It's easy, once you purchase your virtual training membership online through PayPal. Your membership will automatically renew each month.
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFour">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        Who is my Personal Trainer?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                <div class="panel-body">
                                    Your programs are specifically tailored for your requirements. You will talk to a real person, one of Taylor Made Personal Training's trainers. Our trainers will be able to give you excellent and results focused advice that will assist you in achieving your ultimate goals, just like we have done with so many in our Taylor Made Personal Training Studios Australia.
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFive">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                        How regularly do I need to exercise?
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
                                <div class="panel-body">
                                    Your programs are specifically tailored for your requirements. You will talk to a real person, one of Taylor Made Personal Training's trainers. Our trainers will be able to give you excellent and results focused advice that will assist you in achieving your ultimate goals, just like we have done with so many in our Taylor Made Personal Training Studios Australia.
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>

<!--
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/ipad.png" alt="">
                </div>
-->
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->

    <div class="content-section-b">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Daily Workouts</h2>
                    <p class="lead">Do you love variety?</p>
                    <p class="lead">We post a new workout every day (besides Sunday) to make sure you stay motivated and keep acheiving the results you set out to achieve!</p>
                </div>
                <div class="col-lg-5 col-sm-pull-6  col-sm-6">
                    <img class="img-responsive" src="img/dog.png" alt="">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->

    <div class="content-section-a">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">A Real Online Coach</h2>
                    <p class="lead">We don't create one program and hope it works for everyone. We are a team of real life qualified coaches & trainers currently working in the industry. We will ask you for some specific goals and work with you to set the perfect program for your training availability.</p>
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/phones.png" alt="">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->
    
    <div class="content-section-b">

        <div class="container">
            
            <h2 class="section-heading">Follow us on Instagram</h2>
            <!-- LightWidget WIDGET -->
            <script src="//lightwidget.com/widgets/lightwidget.js"></script><iframe src="//lightwidget.com/widgets/efde343704ad5656a6cbf421d1411c00.html" id="lightwidget_efde343704" name="lightwidget_efde343704"  scrolling="no" allowtransparency="true" class="lightwidget-widget" style="width: 100%; border: 0; overflow: hidden;"></iframe>

    
            </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->