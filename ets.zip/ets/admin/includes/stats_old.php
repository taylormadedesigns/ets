<?php

class Stats extends Db_object {
    
    protected static $db_table_fields = array();
    public $rhr;
    public $bp;
    public $bp_d;
    public $user_id;
    public $height;
    public $weight;
    public $fat;
    public $chest;
    public $waist;
    public $waist_sp;
    public $hips;
    public $user_stat;
    public $stat_value;
    public $date;
    
    
    public static function find_stat_by_id($id,$table) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM " . $table . " WHERE user_id = {$id} ORDER BY id DESC LIMIT 1");
        
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
    
    public function create_stat($user_id, $stat, $value) {
        global $database;
        
        $database->escape_string($user_id);
        $database->escape_string($stat);
        $database->escape_string($value);
            
        $sql = "INSERT INTO body_stats_" . $stat . " (user_id," . $stat . ")";
        $sql .= "VALUES ('{$user_id}','{$value}')";        
                                         
        if($database->query($sql)){
            
            $this->id = $database->the_insert_id();
            
            return true;
            
        } else {

            return false;
        }
        
        
        } // create method
               
} // end of class

$stats = new Stats();



?>


