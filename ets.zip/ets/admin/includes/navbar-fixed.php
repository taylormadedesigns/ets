
    
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <?php require_once('above_nav.php'); ?>
        <div class="container">
            
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">My Profile</a>
                    </li>
                    <li class='nav-plus'>
                        +
                    </li>
                    <li>
                        <a href="how_does_it_work.php">My Program</a>
                    </li>
                    <li class='nav-plus'>
                        +
                    </li>
                    <li>
                        <a href="programs.php">My Food Diary</a>
                    </li>
                    <li class='nav-plus'>
                        +
                    </li>
                    <li>
                        <a href="nutrition.php">My Records</a>
                    </li>
                    <li class='nav-plus'>
                        +
                    </li>
                    <li>
                        <a href="index.php#about">My Trainer</a>
                    </li>
                    <li class='nav-plus'>
                        +
                    </li>
                    <li>
                        <a href="start_now.php">Let's Train</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
        <?php require_once('below_nav.php'); ?>
    </nav>
    