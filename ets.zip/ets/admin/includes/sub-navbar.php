            <div class="content-section-c">
               <div class="container">
                   <div class="row text-center">
                        <div class="col-sm-3">
                            <h2><?php echo date('h:i A'); ?>  </h2>
                            <?php echo strtoupper(date('l M d Y')); ?>
                        </div>
                        <div class="col-sm-3 text-center">
                            <h2 class="">Start Workout</h2>
                            Last workout: <br> 12:15PM Thu 10/10/2016
                            
                        </div>
                        <div class="col-sm-3 text-center">
                            <h2 class="">Log stats</h2>
                            Last logged: <br> 12:15PM Thu 10/10/2016
                            
                        </div>
                        <div class="col-sm-3">
                            <div class="pull-right">
                                <img class="my-img" src="<?php echo $user_id->image_path_and_placeholder();?>" alt="" width="100%">
                                <h4><?php echo ucfirst($user_id->first_name) . " " . ucfirst($user_id->last_name); ?>  </h4> 
                            </div>
                                 
                        </div>
                           
<!--
                       <div class="col-sm-3">
                           <h4>Body Stats</h4>
                           <h2>4</h2>
                       </div>
                       <div class="col-sm-3">
                           <h4>Workouts Completed</h4>
                           <h2>4</h2>
                       </div>
                       <div class="col-sm-3">
                           <h4>Recent Activity</h4>
                           <h2>4</h2>
                       </div>
-->
                   </div>
               </div>
                
            </div>