<?php


class Newsfeed extends Db_object {
    
    protected static $db_table = "newsfeed";
    protected static $db_table_fields = array('id','studio_id','user_id','post','updated','active');
    public $id;
    public $studio_id;
    public $user_id;
    public $post;
    public $updated;
    public $active; 
    
    public static function find_by_id($id,$user_id) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id = '{$user_id}' AND id = '{$id}' LIMIT 1");
        
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
    
    public static function find_all($studio_id) {
        
        return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE studio_id = {$studio_id} ORDER BY updated DESC LIMIT 50");
    }
            
    
} // end of class

$newsfeed = new Newsfeed();


class Newsfeed_likes extends Db_object {
    
    protected static $db_table = "newsfeed_likes";
    protected static $db_table_fields = array('id','studio_id','user_id','post_id');
    public $id;
    public $studio_id;
    public $user_id;
    public $post_id;
    
    public static function find_by_post_id($id) {
        global $database;
        
        $the_result = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE post_id = {$id}");
        
        $total_rows = 0;
        foreach ($the_result as $rows) {
            $total_rows++;
        }
        return $total_rows;
        
    }
    
    public static function find_by_id($id,$user_id) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id = {$user_id} AND post_id = {$id} LIMIT 1");
        
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }

    public static function find_all() {
        
        return static::find_by_query("SELECT * FROM " . static::$db_table . " ORDER BY time DESC");
    }
    
    public function save() {
        
        return isset($this->id) ? $this->update() : $this->create();
        
    }
    
    public function create() {
        global $database;
        
        $properties = $this->clean_properties();
        
        $sql = "INSERT INTO " . static::$db_table . "(" . implode(",", array_keys($properties)) . ")";
        $sql .= "VALUES ('". implode("','", array_values($properties)) ."')";        
                                         
        if($database->query($sql)){
            
            $this->id = $database->the_insert_id();
            
            return true;
            
        } else {
            
            return false;
        }
        
        
    } // create method
    
    public function update() {
        global $database;
        
        $properties = $this->clean_properties();
        $properties_pairs = array();
        
        foreach ($properties as $key => $value){ 
            $properties_pairs[] = "{$key}='{$value}'";   
        }
        
        $sql = "UPDATE " . static::$db_table . " SET ";
        $sql .= implode(", ", $properties_pairs);
        $sql .= " WHERE user_id = " . $database->escape_string($this->id);
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
    
    public function delete() {
        global $database;
        
        $sql = "DELETE FROM " . static::$db_table . " ";
        $sql .= "WHERE id = " . $database->escape_string($this->id);
        $sql .= " LIMIT 1";
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
    public function delete_likes() {
        global $database;
        
        $sql = "DELETE FROM " . static::$db_table . " ";
        $sql .= "WHERE post_id = " . $database->escape_string($this->post_id);
        $sql .= " LIMIT 1";
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
            
    
} // end of class

$newsfeed_likes = new Newsfeed_likes();


class Newsfeed_comments extends Db_object {
    
    protected static $db_table = "newsfeed_comments";
    protected static $db_table_fields = array('id','studio_id','user_id','post_id','post_comment');
    public $id;
    public $studio_id;
    public $user_id;
    public $post_id;
    public $post_comment;
    
    public static function find_by_post_id($id) {
        global $database;
        
        $the_result = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE post_id = {$id}");
        
        $total_rows = 0;
        foreach ($the_result as $rows) {
            $total_rows++;
        }
        return $total_rows;
        
    }
    
    public static function find_by_id($id,$user_id) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id = {$user_id} AND post_id = {$id} LIMIT 1");
        
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
    
    public static function find_all_post_comments($id) {
        
        return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE post_id = {$id}");
        
    }

    public static function find_all() {
        
        return static::find_by_query("SELECT * FROM " . static::$db_table . " ORDER BY time DESC");
    }
    
    public function save() {
        
        return isset($this->id) ? $this->update() : $this->create();
        
    }
    
    public function create() {
        global $database;
        
        $properties = $this->clean_properties();
        
        $sql = "INSERT INTO " . static::$db_table . "(" . implode(",", array_keys($properties)) . ")";
        $sql .= "VALUES ('". implode("','", array_values($properties)) ."')";        
                                         
        if($database->query($sql)){
            
            $this->id = $database->the_insert_id();
            
            return true;
            
        } else {
            
            return false;
        }
        
        
    } // create method
    
    public function update() {
        global $database;
        
        $properties = $this->clean_properties();
        $properties_pairs = array();
        
        foreach ($properties as $key => $value){ 
            $properties_pairs[] = "{$key}='{$value}'";   
        }
        
        $sql = "UPDATE " . static::$db_table . " SET ";
        $sql .= implode(", ", $properties_pairs);
        $sql .= " WHERE user_id = " . $database->escape_string($this->id);
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
    
    public function delete() {
        global $database;
        
        $sql = "DELETE FROM " . static::$db_table . " ";
        $sql .= "WHERE id = " . $database->escape_string($this->id);
        $sql .= " LIMIT 1";
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
    public function delete_likes() {
        global $database;
        
        $sql = "DELETE FROM " . static::$db_table . " ";
        $sql .= "WHERE post_id = " . $database->escape_string($this->post_id);
        $sql .= " LIMIT 1";
        
        $database->query($sql);
        
        return (mysqli_affected_rows($database->connection) == 1 ) ? true : false;
        
    }
            
    
} // end of class

$newsfeed_comments = new Newsfeed_comments();

?>


