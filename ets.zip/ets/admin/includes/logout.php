<?php require_once("header.php"); ?>

<?php

$session->logout();
redirect('../login.php');

?>