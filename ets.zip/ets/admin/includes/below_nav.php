<div class="below_nav">
    <div class="container">
        <div class="text-center">
           <?php 
            $user_id = $session->user_id;
            $user_id = User::find_by_id($user_id);
            ?>
            Welcome <?php echo ucfirst($user_id->first_name) . " " . ucfirst($user_id->last_name); ?>
        </div>    
    </div>
    
</div>
    