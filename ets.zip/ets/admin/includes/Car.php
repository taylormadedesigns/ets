<?php
class Car {
    
    public function run(){
        
        echo "Hello this is running!";
    }
    
}




?>