<?php

class Stats extends Db_object {
    
    protected static $db_table_fields = array('id','body_stat','body_stat_label','active');
    protected static $db_table = "body_stats_defaults";
    public $body_stat;
    public $id;
    public $active;
    public $body_stat_label;
    public $body_stat_result;
    public $mod_date;
    
    public $rhr;
    public $bp;
    public $bp_d;
    public $user_id;
    public $height;
    public $weight;
    public $fat;
    public $chest;
    public $waist;
    public $waist_sp;
    public $hips;
    public $user_stat;
    public $stat_value;
    public $date;
    
    
    public static function find_all_stats_by_studio_and_client_id($studio_id,$client_id) {
        
        return static::find_by_query("SELECT * FROM body_stats WHERE studio_id = '{$studio_id}' AND user_id = '{$client_id}'");
    }
    
    public static function find_stat_history($stat, $limit) {
        
        global $database;
        global $session;
        
        if($session->is_signed_in()) {
            
            $id = $session->user_id;
            $studio_id = $session->studio_id;
            
            return $the_result_array = static::find_by_query("SELECT * FROM (SELECT * FROM body_stats WHERE user_id = {$id} AND studio_id = {$studio_id} AND body_stat = {$stat} ORDER BY id DESC LIMIT {$limit}) sub ORDER BY id ASC");


            
            
        } else {
            
            return false;
            
        }
        
    }
    
    public static function find_stat_by_result($stat_default, $client) {
        
        global $database;
        global $session;
        
        if($session->is_signed_in()) {
            
            $id = $client;
            $studio_id = $session->studio_id;
            
            $the_result_array = static::find_by_query("SELECT * FROM body_stats WHERE user_id = {$id} AND studio_id = {$studio_id} AND body_stat = '{$stat_default}' ORDER BY id DESC LIMIT 1");
        
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
            
        } else {
            
            return false;
            
        }
        
    }
    
    public static function find_stat_by_id($table,$id) {
        global $database;
        global $session;
        
        if($session->is_signed_in()) {
            
            
            $id = !isset($id) ? $session->user_id : $id;
            
            $the_result_array = static::find_by_query("SELECT * FROM " . $table . " WHERE user_id = {$id} ORDER BY id DESC LIMIT 1");
        
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
            
        } else {
            
            return false;
            
        }
        
    }
    
    public function create_stat($user_id, $stat, $value) {
        global $database;
        
        $database->escape_string($user_id);
        $database->escape_string($stat);
        $database->escape_string($value);
            
        $sql = "INSERT INTO body_stats_" . $stat . " (user_id," . $stat . ") ";
        $sql .= "VALUES ('{$user_id}','{$value}')";        
                                         
            if($database->query($sql)){

                $this->id = $database->the_insert_id();

                return true;

            } else {

                return false;
            }
        
        
        } // create method
    
    
    public static function find_by_stat_type($stat) {
        global $database;
        
         $the_result_array = static::find_by_query("SELECT * FROM body_stats_defaults WHERE body_stat = '{$stat}' ORDER BY id DESC LIMIT 1");
        
        if(!empty($the_result_array)){
            
            $find_stat = array_shift($the_result_array);
            
            return $find_stat->id;
            
        } else {
            
            return false;
            
        }
        
        
        
    }
    
    public function create_stat_new($user_id, $stat, $value) {
        global $database;
        global $session;
        $database->escape_string($user_id);
        $database->escape_string($stat);
        $database->escape_string($value);
        $studio_id = $session->studio_id;
        
        $find_stat_number = static::find_by_stat_type($stat);
            
        $sql = "INSERT INTO body_stats (studio_id,user_id,body_stat,body_stat_result,updated_by) ";
        $sql .= "VALUES ('{$studio_id}','{$user_id}','{$find_stat_number}','{$value}','{$session->user_id}')";        
                                         
            if($database->query($sql)){

                $this->id = $database->the_insert_id();

                return true;

            } else {

                return false;
            }
        
        
    } // create method
    
    public function find_stat_number($stat) {
        
         global $database;
        
            
        $the_result_array = static::find_by_query("SELECT * FROM body_stats_defaults WHERE body_stat = '{$stat}' ORDER BY id DESC LIMIT 1");
        
        return !empty($the_result_array) ? $this->stat_number_object($the_result_array) : false;
        
    }
    
    public function stat_number_object($the_result_array) {
        
        return $the_result_array->id;
    }
    
    public function stat_comparisons($stat,$result) {
        
        if($result) {
            
            $label_warning_class = "success";
            switch($stat) {

                case "rhr":
                    if($result > 80) {
                        $label_warning_class = "danger";
                        $result = "Below Average";
                    } else if ($result > 59 && $result < 81) {
                        $label_warning_class = "warning";
                        $result = "Average";
                    } else {
                        $result = "Above Average";
                    }

                    break;

                case "bp":
                    if($result > 140) {
                        $label_warning_class = "danger";
                        $result = "Too High";
                    } else if ($result > 120 && $result < 141) {
                        $label_warning_class = "warning";
                        $result = "Mod High";
                    } else {
                        $result = "Normal";
                    }
                    break;

                case "weight":
                    if($result > 140) {
                        $label_warning_class = "danger";
                        $result = "Too High";
                    } else if ($result > 120 && $result < 141) {
                        $label_warning_class = "warning";
                        $result = "Mod High";
                    } else {
                        $result = "Normal";
                    }
                    break;

                case "fat":
                    if($result > 22) {
                        $label_warning_class = "danger";
                        $result = "Too High";
                    } else if ($result > 16 && $result < 23) {
                        $label_warning_class = "warning";
                        $result = "Mod High";
                    } else {
                        $result = "Normal";
                    }
                    break;

                case "waist":
                    if($result > 100) {
                        $label_warning_class = "danger";
                        $result = "Too High";
                    } else if ($result > 80 && $result < 101) {
                        $label_warning_class = "warning";
                        $result = "Mod High";
                    } else {
                        $result = "Normal";
                    }
                    break;

                default:
                        $result = "";
                        $label_warning_class = "";

            }

            return $label = "<a tabindex='0' class='label label-" . $label_warning_class . "' role='button' data-toggle='popover' data-trigger='focus' title='Dismissible popover' data-content='And here's some amazing content. It's very engaging. Right?'>" . $result . "</a>";
            
        } else {
            return false;
        }
        
           
    }
    
               
} // end of class

$stats = new Stats();



?>


