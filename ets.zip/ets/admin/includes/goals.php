<?php

class Goals extends Db_object {
    
    protected static $db_table_fields = array('id','goal');
    protected static $db_table = "goals_defaults";
    public $studio_id;
    public $goal;
    public $id;
    public $goal_answer_type;
    public $goal_answer;
    public $goals_answer;
    
    
    public function get_client_goal_weight($studio_id,$client_id, $id) {
        global $database;
        
        
        $the_result_array = static::find_by_query("SELECT * FROM goals WHERE goals_studio_id = '{$studio_id}' AND goals_client_id = '{$client_id}' AND goals_type = {$id} LIMIT 1");
        
        return $result = !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
    
    public function get_client_goal_answer_by_answer_id($studio_id,$client_id,$id) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM goals WHERE goals_studio_id = '{$studio_id}' AND goals_client_id = '{$client_id}' AND goals_type = '{$id}' ORDER BY id DESC LIMIT 1");
        
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
    
    public static function find_all_client_goal_answers($studio_id, $client_id) {

        return static::find_by_query("SELECT * FROM goals WHERE goals_studio_id = {$studio_id} AND goals_client_id = {$client_id} ORDER BY id ASC");
        
    }
    
    
    public static function find_all_goal_answers($id) {

        return static::find_by_query("SELECT * FROM goals_defaults_answers WHERE goal_question_id = {$id} ORDER BY id ASC");
        
    }
    
    
    
//    public static function find_goal_by_result($goal_default) {
//        
//        global $database;
//        global $session;
//        
//        if($session->is_signed_in()) {
//            
//            $id = $session->user_id;
//            
//            $the_result_array = static::find_by_query("SELECT * FROM body_goals WHERE user_id = {$id} AND body_goal = '{$goal_default}' ORDER BY id DESC LIMIT 1");
//        
//            return !empty($the_result_array) ? array_shift($the_result_array) : false;
//            
//        } else {
//            
//            return false;
//            
//        }
//        
//    }
    
    public static function find_goal_by_id($table) {
        global $database;
        global $session;
        
        if($session->is_signed_in()) {
            
            $id = $session->user_id;
            
            $the_result_array = static::find_by_query("SELECT * FROM " . $table . " WHERE user_id = {$id} ORDER BY id DESC LIMIT 1");
        
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
            
        } else {
            
            return false;
            
        }
        
    }
    
    public static function find_goal_answer_by_id($goal) {
        global $database;
        global $session;
        
        if($session->is_signed_in()) {
            
            $id = $session->user_id;
            
            $the_result_array = static::find_by_query("SELECT * FROM goals_defaults_answers WHERE goal_question_id = {$goal} ORDER BY id DESC LIMIT 1");
        
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
            
        } else {
            
            return false;
            
        }
        
    }
    
    public function display_question_answers($answer) {
            
            return isset($answer) ? $answer : false;
            
    }
    
    public function save_goals($insert_array, $client){
        foreach ($insert_array as $goal_number => $goal_input) {
            
            global $session;
            
            if(isset($client) && isset($session->studio_id)) {
                
                $this->save_goal($session->studio_id, $session->user_id, $goal_number, $goal_input, $client);
                
            } else {
                return false;
            }
                                    
        }
    }
    
    public function save_goal($studio_id, $user_id, $goal, $value, $client) {
        global $database;
        
        $database->escape_string($studio_id);
        $database->escape_string($user_id);
        $database->escape_string($goal);
        $database->escape_string($value);
            
        $sql = "INSERT INTO goals (goals_studio_id,goals_client_id,goals_type,goals_answer,updated_by) ";
        $sql .= "VALUES ('{$studio_id}','{$client}','{$goal}','{$value}', '{$user_id}')";        
                                         
            if($database->query($sql)){

                $this->id = $database->the_insert_id();

                return true;

            } else {

                return false;
            }
        
        
        } // create method
    
    
    public static function find_by_goal_type($goal) {
        global $database;
        
         $the_result_array = static::find_by_query("SELECT * FROM body_goals_defaults WHERE body_goal = '{$goal}' ORDER BY id DESC LIMIT 1");
        
        if(!empty($the_result_array)){
            
            $find_goal = array_shift($the_result_array);
            
            return $find_goal->id;
            
        } else {
            
            return false;
            
        }
        
        
        
    }
    
    public function create_goal_new($user_id, $goal, $value) {
        global $database;
        
        $database->escape_string($user_id);
        $database->escape_string($goal);
        $database->escape_string($value);
        
        $find_goal_number = static::find_by_goal_type($goal);
            
        $sql = "INSERT INTO body_goals (user_id,body_goal,body_goal_result) ";
        $sql .= "VALUES ('{$user_id}','{$find_goal_number}','{$value}')";        
                                         
            if($database->query($sql)){

                $this->id = $database->the_insert_id();

                return true;

            } else {

                return false;
            }
        
        
    } // create method
    
    public function find_goal_number($goal) {
        
         global $database;
        
            
        $the_result_array = static::find_by_query("SELECT * FROM body_goals_defaults WHERE body_goal = '{$goal}' ORDER BY id DESC LIMIT 1");
        
        return !empty($the_result_array) ? $this->goal_number_object($the_result_array) : false;
        
    }
    
    public function goal_number_object($the_result_array) {
        
        return $the_result_array->id;
    }
    
    public static function food_intake_requirements($studio_id,$client_id,$goal_id) {
        global $database;
        
        $the_result_array = static::find_by_query("SELECT * FROM goals WHERE goals_studio_id = '{$studio_id}' AND goals_client_id = '{$client_id}' AND goals_type = '{$goal_id}' ORDER BY id DESC LIMIT 1");
        
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
        
    }
               
} // end of class

$goals = new goals();



?>


