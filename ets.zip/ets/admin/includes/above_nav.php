
<div class="above_nav">
    <div class="container-fluid">
       
        <div id="menu-toggle" class="my-icon-container">
            <div class="my-icon-bar"></div>
            <div class="my-icon-bar"></div>
            <div class="my-icon-bar"></div>  
        </div>
        <a class="" href="index.php">
            <img class="logo-image" src="img/tmpt_virtual_training_logo.png">
            <img class="logo-image-small" src="img/tmpt_online_logo_small.png">
        </a>
            
<!--            <a class="btn btn-xs btn-default" href="includes/logout.php">Log Out</a>-->
            
            
 <!-- alerts button. Activate when ready to code ------>
<!--
                <div class="nav-dropdown">
                    <span class="dropdown-toggle glyphicon glyphicon-bell" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <span class="nav-badge" data-badge="2"></span>
                    </span>
                
                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                        <li><a href="my_profile.php"><span class="glyphicon glyphicon-user"></span> Alerts</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="includes/logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a></li>
                    </ul>
                </div>
-->
                
                <div class="nav-dropdown pull-right">
                    <span class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <div class="profile-pic-xs" style="background: url(<?php echo $user_id->image_path_and_placeholder();?>) 50% 50% no-repeat; background-size: cover;"></div>
                    </span>
                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                        <li><a href="my_profile.php"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
    <!--                    <li><a href="#"><span class="glyphicon glyphicon-cutlery"></span> Add Recipe</a></li>-->
                        <li role="separator" class="divider"></li>
                        <li><a href="includes/logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a></li>
                    </ul>
                </div>
          
            



    </div>
    
</div>
    