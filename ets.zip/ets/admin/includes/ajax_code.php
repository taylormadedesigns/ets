<?php require_once('init.php');

$user = new User();

if(isset($_POST['image_name'])) {

    $user->ajax_save_user_image(urldecode($_POST['image_name']), $_POST['user_id']);
        
} 


if(isset($_POST['photo_id'])) {
    
    Photo::display_sidebar_data($_POST['photo_id']);
    

} 

if(isset($_POST['value'])) {
    $id = isset($_POST['client_id']) ? $_POST['client_id'] : $_POST['user_id'];
    
    if ($_POST['stat'] != "bp" && $_POST['stat'] != "bp_d" && $_POST['value'] > 0) {
        
        $stats->create_stat_new($id, $_POST['stat'], $_POST['value']); 
        $text = Stats::find_stat_by_id("body_stats",$id);
        echo " - Last saved: " . date('h:iA d/m/Y',strtotime($text->mod_date));
    } else {
        
        $database->query("INSERT INTO body_stats (studio_id,user_id,body_stat,body_stat_result,updated_by) VALUES ('{$session->studio_id}','{$id}','2','{$_POST['bp']}','{$session->user_id}')");
       
        $database->query("INSERT INTO body_stats (studio_id,user_id,body_stat,body_stat_result,updated_by) VALUES ('{$session->studio_id}','{$id}','3','{$_POST['bp_d']}','{$session->user_id}')");
        
        $text = Stats::find_stat_by_id("body_stats",$id);
        echo " - Last saved: " . date('h:iA d/m/Y',strtotime($text->mod_date));
        
    }
    
}
//
//if(isset($_POST['client_id'])) {
//    echo "YES";
//}


?>


