$(document).ready(function(){
    
//    var user_href;
//    var user_href_split;
//    var user_id;
//
//    var image_src;
//    var image_href_split;
//    var image_name;
//    var photo_id;
//    
//    $(".modal_thumbnails").click(function(){
//        
//        $('#set_user_image').prop('disabled', false);
//        
//        user_href = $('#user_id').prop('href');
//        user_href_split = user_href.split("=");
//        user_id = user_href_split[user_href_split.length -1];
//        
//        image_src = $(this).prop('src');
//        image_href_split = image_src.split("/");
//        image_name = image_href_split[image_href_split.length -1];
//        
//        photo_id = $(this).attr('data');
//        
//        $.ajax({
//            url: "includes/ajax_code.php",
//            data:{photo_id: photo_id},
//            type: "POST",
//            success:function(data){
//                if(!data.error){    
//                    $("#modal_sidebar").html(data);
//                }
//            }
//        });
//
//        
//    });
    
var $_GET = {};
document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
    function decode(s) {
        return decodeURIComponent(s.split("+").join(" "));
    }
    $_GET[decode(arguments[1])] = decode(arguments[2]);
});
var client_id = $_GET["client_id"];
    
    var height;
    var stat;
    var user_id;
    var bp;
    var bp_d;

    $(".save-stat").click(function(e){
        e.preventDefault();
        
        stat            = $(this).parents().siblings().children('input').attr('name');
        value           = $(this).parent().siblings().children('input').val();
        user_id         = this.href.substr(this.href.lastIndexOf('=') + 1);
                
        bp              = $("input[name=bp]").val();
        bp_d            = $("input[name=bp_d]").val();
        
        $.ajax({
            url: "includes/ajax_code.php",
            data:{stat: stat, value: value, user_id: user_id, bp: bp, bp_d: bp_d, client_id: client_id},
            type: "POST",
            success:function(data){
                if(!data.error){
                    
                    if(stat == "bp" && (bp == 0 || bp_d == 0)){
                        $("input[name='bp']").parent().removeClass("has-success has-feedback");
                        $("input[name='bp_d']").parent().removeClass("has-success has-feedback");
                        $("input[name='bp']").parent().addClass("has-error has-feedback");
                        $("input[name='bp_d']").parent().addClass("has-error has-feedback");
                        $("input[name='bp_d']").parent().parent().children('.col-xs-12').append('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Not Saved!</strong> Please enter a value.</div>');
                        $(".alert").delay(2000).fadeOut(1000);
                        
                    } else if(stat == "bp" && (bp > 0 && bp_d > 0)) {
                        $("input[name='bp']").parent().removeClass("has-error has-feedback");
                        $("input[name='bp_d']").parent().removeClass("has-error has-feedback");
                        $("input[name='bp']").parent().addClass("has-success has-feedback");
                        $("input[name='bp_d']").parent().addClass("has-success has-feedback");
                        $("input[name='bp_d']").parent().parent().children('.col-xs-12').append('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Saved!</strong></div>');
                        $(".alert").delay(2000).fadeOut(1000);
                        
                        
                    
                    } else if(value == 0){

                        $("input[name=" + stat + "]").parent().addClass("has-error has-feedback");
                        $("input[name=" + stat + "]").parent().prepend('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Not Saved!</strong> Please enter a value.</div>');
                        $(".alert").delay(2000).fadeOut(1000);

                    } else {
                        $("input[name=" + stat + "]").parent().parent().find('span').text(data);
                        $("input[name=" + stat + "]").val(value);
                        $("input[name=" + stat + "]").parent().removeClass("has-error has-feedback");
                        $("input[name=" + stat + "]").parent().addClass("has-success has-feedback");
                        $("input[name=" + stat + "]").parent().prepend('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Saved!</strong></div>');
                        $(".alert").delay(2000).fadeOut(1000);

                    }
                           
                     
                    
//                    alert('working');
//                    location.reload(true);
                }
            }
        });
    
    });
//    
//tinymce.init({ selector:'textarea' });   
});