<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(isset($_GET['post_id'])){
    $post = Newsfeed::find_by_id($_GET['post_id'],$session->user_id);
    
    if($post){
        $post->id = $_GET['post_id'];
        $post->delete();
        $newsfeed_likes->post_id = $_GET['post_id'];
        $newsfeed_likes->delete_likes();
        $session->message('<div class="alert alert-success alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Post deleted</div>');
        redirect('newsfeed.php');
    }
}

?>