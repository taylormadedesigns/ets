<?php require_once("includes/header.php"); ?>

<?php
if($session->is_signed_in()){
    redirect('index.php'); 
}

if(isset($_POST['submit'])) {
    
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    
    // method to check db user
    
    $user_found = User::verify_user($username, $password);
    
    
    if($user_found) {
            
        $session->login($user_found);

        if(isset($_SESSION['LAST_PAGE'])) {
            redirect($_SESSION['LAST_PAGE']);
        } else {
            redirect("index.php");
        }
        
    } else {
        
        $the_message = "<div class='alert alert-danger'>Your password or username are incorrect</div>";
    }
    
    
    
} else {
    
    $the_message = "";
    $username = "";
    $password = "";
    
}


?>

<div class="content-section-d" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4" style="margin-top: 200px; margin-bottom: 200px;">

                <div class="col-xs-8 col-xs-offset-2 col-sm-12 col-sm-offset-0 text-center">
                    <img src="img/tmpt_virtual_training_logo.png" alt="" class="img-responsive" width="100%;">
                </div>
                
                <div class="col-xs-12">
                    <h4 class="bg-danger"><?php echo $the_message; ?></h4>

                <form id="login-id" action="" method="post">

                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username" value="<?php echo htmlentities($username); ?>" autocomplete="on">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password" value="<?php echo htmlentities($password); ?>">
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary pull-right">
                    </div>


                </form>
                </div>

            </div> 
        </div>
        <?php
$playerrecords = array (1,2,3,4,5);
$players_seen = array (1,5);

$result=array_diff($playerrecords,$players_seen);
$results_not_seen = $result;
$a = array_rand($results_not_seen);
$b = $results_not_seen[$a];
echo $b;
        ?>
    </div>
    <?php include("includes/footer.php"); ?>
</div>
