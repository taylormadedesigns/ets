<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
 
    $user           = User::find_by_id($session->user_id);
    $user_rhr       = Stats::find_stat_by_id($session->user_id,'body_stats_rhr');
    $user_bp        = Stats::find_stat_by_id($session->user_id,'body_stats_bp');
    $user_height    = Stats::find_stat_by_id($session->user_id,'body_stats_height');
    $user_weight    = Stats::find_stat_by_id($session->user_id,'body_stats_weight');
    $user_fat       = Stats::find_stat_by_id($session->user_id,'body_stats_fat');
    $user_chest     = Stats::find_stat_by_id($session->user_id,'body_stats_chest');
    $user_waist     = Stats::find_stat_by_id($session->user_id,'body_stats_waist');
    $user_waist_sp  = Stats::find_stat_by_id($session->user_id,'body_stats_waist_sp');
    $user_hips      = Stats::find_stat_by_id($session->user_id,'body_stats_hips');
    
}
?>




<!--    <a name="about"></a>-->
   
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
           
<?php include ("includes/sub-navbar.php"); ?>
          
            <div class="content-section-b">    
                <div class="container">    
                    <div class="row">
                        <div class="col-xs-12">
                            <?php echo $session->message(); ?>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="rhr">Resting Heart Rate:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="rhr" value="<?php if ($user_rhr) {echo $user_rhr->rhr;} ?>" placeholder="bpm">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="bp">Blood Pressure:</label>
                                    </div>
                                    <div class="col-xs-4">
                                        <input type="text" class="form-control" name="bp" value="<?php if ($user_bp) {echo $user_bp->bp;} ?>" placeholder="Systolic">
                                    </div>
                                    <div class="col-xs-1 text-center">
                                        /
                                    </div>
                                    <div class="col-xs-4">
                                        <input type="text" class="form-control" name="bp_d" value="<?php if ($user_bp) {echo $user_bp->bp_d;} ?>" placeholder="Diastolic">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                        </div>   
                        <div class="col-xs-12"> 
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="height">Height:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="height" value="<?php if ($user_height) {echo $user_height->height;} ?>" placeholder="cm">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="weight">Weight:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="weight" value="<?php if ($user_weight) {echo $user_weight->weight;} ?>" placeholder="kg">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="bodyfat">Body Fat %:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="fat" value="<?php if ($user_fat) {echo $user_fat->fat;} ?>" placeholder="%">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="Chest">Chest:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="chest" value="<?php if ($user_chest) {echo $user_chest->chest;} ?>" placeholder="%">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="Chest">Waist:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="waist" value="<?php if ($user_waist) {echo $user_waist->waist;} ?>" placeholder="%">  
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="Waist">Waist (smallest point):</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="waist_sp" value="<?php if ($user_waist_sp) {echo $user_waist_sp->waist_sp;} ?>" placeholder="cm">
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>
                            <div class="row form-group">
                                    <div class="col-xs-12">
                                        <label for="Waist">Hips:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <input type="text" class="form-control" name="hips" value="<?php if ($user_hips) {echo $user_hips->hips;} ?>" placeholder="cm">
                                    </div>
                                    <div class="col-xs-3 pull-right">
                                        <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                                    </div>
                            </div>    
                        </div>
<!--
                        <div class="col-xs-12 col-sm-4 text-center">
                            <h4>Latest Activity</h4>
                        </div>
-->
                    </div>
                </div>
            </div>
            <?php include('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
