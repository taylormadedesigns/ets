<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
    
    $user           = User::find_by_id($session->user_id);
    $user_rhr       = Stats::find_stat_by_id('body_stats_rhr');
    $user_bp        = Stats::find_stat_by_id('body_stats_bp');
    $user_height    = Stats::find_stat_by_id('body_stats_height');
    $user_weight    = Stats::find_stat_by_id('body_stats_weight');
    $user_fat       = Stats::find_stat_by_id('body_stats_fat');
    $user_chest     = Stats::find_stat_by_id('body_stats_chest');
    $user_waist     = Stats::find_stat_by_id('body_stats_waist');
    $user_waist_sp  = Stats::find_stat_by_id('body_stats_waist_sp');
    $user_hips      = Stats::find_stat_by_id('body_stats_hips');
  
}
?>




<!--    <a name="about"></a>-->
   
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
           
<?php include ("includes/sub-navbar.php"); ?>
          
            <div class="content-section-b">
                <div class="container">
                    <div class="row"> 
                        <div class="col-xs-12">
                            <h4 class="my-section-heading">Photos</h4>
                        </div>
                        <div class="col-xs-4 col-sm-4 text-center">
                            <div class="col-xs-4 col-xs-offset-4 col-sm-12 col-sm-offset-0">
                                Front
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <img class="thumbnail" src="<?php echo $user->image_path_and_placeholder();?>" alt="" width="100%" >
                                    </div>
                                    <div class="row">
                                        <input type="file" name="user_image">
                                    </div>
                                    <div class="row"><br>
                                        <input type="submit" class="btn btn-primary pull-right" name="submit-front" value="Upload Front">   
                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="col-xs-4 col-sm-4 text-center">
                            <div class="col-xs-4 col-xs-offset-4 col-sm-12 col-sm-offset-0">
                                Back
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <img class="thumbnail" src="<?php echo $user->image_path_and_placeholder();?>" alt="" width="100%" >
                                    </div>
                                    <div class="row">
                                        <input type="file" name="back_image">
                                    </div>
                                    <div class="row"><br>
                                        <input type="submit" class="btn btn-primary pull-right" name="submit-back" value="Upload Back">   
                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="col-xs-4 col-sm-4 text-center">
                            <div class="col-xs-4 col-xs-offset-4 col-sm-12 col-sm-offset-0">
                                Side
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <img class="thumbnail" src="<?php echo $user->image_path_and_placeholder();?>" alt="" width="100%" >
                                    </div>
                                    <div class="row">
                                        <input type="file" name="side_image">
                                    </div>
                                    <div class="row"><br>
                                        <input type="submit" class="btn btn-primary pull-right" name="submit-side" value="Upload Side">   
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<!--
                        <div class="col-xs-12 col-sm-4 text-center">
                            <h4>Latest Activity</h4>
                        </div>
-->                  
            <?php include('includes/footer.php'); ?>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
 
        
    
    
