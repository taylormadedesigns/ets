<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(isset($_GET['post_id'])){
    $id = Newsfeed_likes::find_by_id($_GET['post_id'],$session->user_id);
    $newsfeed_likes->id         = $id->id;
    $newsfeed_likes->delete();
    redirect('newsfeed.php');
    
}

?>