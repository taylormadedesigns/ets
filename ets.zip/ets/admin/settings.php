<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<!--    <a name="about"></a>-->
   
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
           

           
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                      
                       <?php echo $session->message(); ?>
                       
                        <div class="col-xs-12">
                            <h4 class="my-section-heading text-center">Settings</h4>
                            <div class="panel-group">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        Membership Sign Up Information
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 1:
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 2:
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <a href="" class="btn btn-sm btn-default pull-right">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        Pre Screening
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                1. Are you over 65?
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                2. Do you feel unfit?
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <a href="" class="btn btn-sm btn-default pull-right">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        Initial Session
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 1:
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 2:
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <a href="" class="btn btn-sm btn-default pull-right">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        Weekly Accountability & Results 
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 1:
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                Question 2:
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <a href="" class="btn btn-sm btn-default pull-right">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       
       
        <?php 
        //include('old_content.php'); 
        ?>

            <a  name="contact"></a>
            <div class="footer-banner">

                <div class="container">

                    <div class="row">
                        <div class="col-lg-4">
                            <h2>Connect with us:</h2>
                        </div>
                        <div class="col-lg-8">
                            <ul class="list-inline banner-social-buttons">
                                <li>
                                        <a href="https://instagram.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-instagram fa-fw"></i> <span class="network-name">Instagram</span></a>
                                    </li>
                                    <li>
                                        <a href="https://facebook.com/taylormadepersonaltraining" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                                    </li>
                                    <li>
                                        <a href="https://au.linkedin.com/in/taylor-made-pt-bb467542" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>
                                    </li>
                            </ul>
                        </div>
                    </div>

                </div>
                <!-- /.container -->
            </div>
            <!-- /.banner -->

    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
