<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<!--    <a name="about"></a>-->
<?php $client = isset($_GET['client_id']) ? User::find_by_id($_GET['client_id']) : false; ?> 
<?php $form_type = !empty($_GET['client_form']) ? $_GET['client_form'] : false; ?>
<?php $set_new = !empty($_GET['new']) ? $_GET['new'] : false; ?>  
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
           

           
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                      
                       <?php echo $session->message(); ?>
                       
                        <div class="col-xs-12">
                            <h4 class="my-section-heading text-center">Client Home <?php echo $client ? " - " . $client->first_name . " " . $client->last_name : false ; ?></h4>
                            <span class="pull-right">
                                <a href="?client_id=<?php echo $client->id; ?>&client_form=1" class="btn <?php echo $form_type == 1 ? "btn-primary" : "btn-default"; ?>"><?php echo $client ? $client->first_name . "'s Profile" : false; ?></a>
                                <a href="?client_id=<?php echo $client->id; ?>&client_form=2" class="btn <?php echo $form_type == 2 ? "btn-primary" : "btn-default"; ?>"><?php echo $client ? $client->first_name . "'s Programs" : false; ?></a>
                                <a href="?client_id=<?php echo $client->id; ?>&client_form=3" class="btn <?php echo $form_type == 3 ? "btn-primary" : "btn-default"; ?>"><?php echo $client ? $client->first_name . "'s Goals" : false; ?></a>
                                <a href="?client_id=<?php echo $client->id; ?>&client_form=4" class="btn <?php echo $form_type == 4 ? "btn-primary" : "btn-default"; ?>"><?php echo $client ? $client->first_name . "'s Records" : false; ?></a>
                                <a href="?client_id=<?php echo $client->id; ?>&client_form=5" class="btn <?php echo $form_type == 5 ? "btn-primary" : "btn-default"; ?>"><?php echo $client ? $client->first_name . "'s Body Stats" : false; ?></a>    
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
            switch ($form_type) {
                case 1:
                    include('client_home_widgets/client_profile.php');
                break;
                case 3:
                    include('client_home_widgets/client_goals.php');
                break;
                case 5:
                    include('client_home_widgets/body_stats.php');
                break;
                default: 
                    false;
            } ?>
            
            <?php
            $set_new == "goals" ? include('client_home_widgets/client_goals_new.php') : false; 
            $set_new == "stats" ? include('client_home_widgets/client_stats_new.php') : false; 
            
            ?>

    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
