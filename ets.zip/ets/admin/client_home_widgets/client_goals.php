<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
 
    $user           = User::find_by_id($session->user_id);
    $client         = User::find_by_id($_GET['client_id']);  
    $goals          = Goals::find_all();
    $client_goals   = Goals::find_all_client_goal_answers(1, $_GET['client_id']);
    
}
?>

        
            <div class="content-section-b">    
                <div class="container">    
                  
                    <h4 class="my-section-heading">My Goals</h4>
                    <div class="panel panel-default">
<!--                            <div class="panel-heading">My Goals</div>-->
                        <div class="panel-body">

<?php foreach ($goals as $goal) : ?>

                            <div class="panel-row">
                                <div class="col-sm-6 panel-row-question">
                                    <b><?php echo $goal->goal; ?></b>
                                </div>
                                <div class="col-sm-6 panel-row-question">

<?php $answer = Goals::get_client_goal_answer_by_answer_id($session->studio_id, $_GET['client_id'], $goal->id); ?>
<?php echo $answer ? $answer->goals_answer : "<span class='label label-danger pull-right'>Goal Not Set</span>"; ?>

                                </div>





                            </div>
                            <div class="panel-divider"></div>


<?php endforeach; ?>
                        </div>
                        <div class="panel-footer">
                            <div class="row">
                                <div class="col-xs-12">
                                    <a href="?client_id=<?php echo $client->id; ?>&new=goals" class="btn btn-default pull-right">Set New Goals</a>     
                                </div>
                            </div>
                            
                        </div>
                    </div>    
                    
                </div>
            </div>
