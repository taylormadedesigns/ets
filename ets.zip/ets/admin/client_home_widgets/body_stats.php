   
        <div class="content-section-b">    
            <div class="container">    
                <div class="row">
                <h4 class="my-section-heading">My Stats</h4>
                <?php 
                    
                    if(isset($_GET['history'])) {
                        if($_GET['history'] == 1) {
                            include('widgets/body-stats-history/body_stats_history.php');
                        }
                    } else {
                        include('widgets/body_stats_widget.php');
                    }
   
                ?>

                </div>
            </div>
        </div>

        
    
    
