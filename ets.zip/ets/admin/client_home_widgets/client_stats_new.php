
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
 
    $client           = User::find_by_id($_GET['client_id']);
    $stat           = Stats::find_all();
    
}
?>

            
        <div class="content-section-b">    
            <div class="container">    
                <div class="panel panel-primary">
                    <div class="panel-body">

<?php 
$find_stat = 1;                    
foreach($stat as $stats){

              $stat_result = Stats::find_stat_by_result($find_stat, $client->id);

$find_stat ++;   
?>
<?php 
    if ($stats->body_stat == "bp") { 
?>

                <div class="col-xs-12">
                    <div class="row form-group">
                        <div class="col-xs-12">
                            <label for="bp">
                            <?php echo $stats->body_stat_label;?>
                                <span class="last_saved_date"><?php echo $stat_result ? " - Last saved: " . date('h:iA d/m/Y',strtotime($stat_result->mod_date)) : false; ?></span>
                            </label>
                        </div>
                        <div class="col-xs-4">
                            <input type="text" class="form-control" name="<?php echo $stats->body_stat;?>" value="<?php if ($stat_result) {echo $stat_result->body_stat_result;} ?>" placeholder="Systolic">
                        </div>
                        <div class="col-xs-1 text-center">
                            /
                        </div>
                        <div class="col-xs-4">
                            <?php $stat_result = Stats::find_stat_by_result(3, $client->id); ?>
                            <input type="text" class="form-control" name="bp_d" value="<?php if ($stat_result) {echo $stat_result->body_stat_result;} ?>" placeholder="Diastolic">  
                        </div>
                        <div class="col-xs-3 pull-right">
                            <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                        </div>
                    </div>
                </div>

<?php 
    } else if ($stats->body_stat == "bp_d") {

    } else { 
?>


                <div class="col-xs-12">
                    <div class="row form-group">
                        <div class="col-xs-12">
                            <label for="<?php echo $stats->body_stat;?>">
                                <?php echo ucfirst($stats->body_stat_label);?> <span class="last_saved_date"><?php echo $stat_result ? " - Last saved: " . date('h:iA d/m/Y',strtotime($stat_result->mod_date)) : false; ?></span>  
                            </label>
                        </div>
                        <div class="col-xs-9">
                            <input type="text" class="form-control" name="<?php echo $stats->body_stat;?>" value="<?php if ($stat_result) {echo $stat_result->body_stat_result;}?>" placeholder="Enter <?php echo ucfirst($stats->body_stat_label);?>">  
                        </div>
                        <div class="col-xs-3 pull-right">
                            <a href="" class="btn btn-primary pull-right save-stat">Save</a>    
                        </div>
                    </div>    
                </div> 
<?php 
    }
} 
?>

                    </div>
                    <div class="panel-footer">
                        <a href="body_stats.php?id=<?php echo $user_id->id; ?>" class="btn btn-primary">See History</a>
                        <a href="body_stats.php?id=<?php echo $user_id->id; ?>" class="btn btn-default">Back</a>
                    </div>
                </div>
            </div>
        </div>
        
        
    
    
