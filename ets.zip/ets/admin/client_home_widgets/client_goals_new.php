<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
    
    $client         = User::find_by_id($_GET['client_id']);
    $user           = User::find_by_id($client->id);
    $goals          = Goals::find_all(); 
}
?>
         
        <div class="content-section-b">    
            <div class="container">    
<?php echo $session->message(); ?>
                <form action="" method="post">
                    <div class="panel panel-default">
                        <div class="panel-body">
<?php
$insert_array = array();
$value = null;
$class_error = null;

foreach($goals as $goal) {
?>
<?php
    if(isset($_POST['submit'])) {

        if(!empty($_POST[$goal->id])){
            $insert_array[$goal->id] = $_POST[$goal->id];
            $value = $_POST[$goal->id]; 
            $class_error = "has-success";
        } else {
            $value = null;
            $class_error = "has-error";
        }

    } 
?>
                            <div class="answer">
                                <label for="<?php echo $goal->id; ?>"><?php echo $goal->goal; ?></label>
                                <div class="form-group <?php echo $class_error;?>">
<?php
$goal_answer_type = Goals::find_goal_answer_by_id($goal->id);
$goal_answer = Goals::find_all_goal_answers($goal->id);
?>
<?php $answer = Goals::get_client_goal_answer_by_answer_id($session->studio_id, $client->id, $goal->id); ?>
<?php $value = $answer ? $answer->goals_answer : null; ?>
<?php       
    if($goal_answer) {

        $input_type = Goals::display_question_answers($goal_answer_type->goal_answer_type);

        if($input_type == "input") {
?>
                                   
                                    <input type="text" id="<?php echo $goal->id; ?>" name="<?php echo $goal->id; ?>" class="form-control" placeholder="Enter Answer" value="<?php echo $value; ?>">
                                   
<?php                
        } else if ($input_type == "select") {

?>
                                    <select name="<?php echo $goal->id; ?>" id="<?php echo $goal->id; ?>" class="form-control">
                                        <option disabled selected>Please Choose</option>
                                        <?php foreach($goal_answer as $i) { ?>
                                        
                                        <option value="<?php echo $i->goal_answer; ?>" <?php echo $value == $i->goal_answer ? "selected" : false; ?>><?php echo $i->goal_answer; $value?></option>
                                
                                        <?php } ?>
                                    </select> 

<?php                
        } else if ($input_type == "select-range") {
            $range = explode(',', $goal_answer_type->goal_answer);
            $val_1 = array_values($range)[0];
            $val_2 = array_values($range)[1];
            

?>
                                    <select name="<?php echo $goal->id; ?>" id="<?php echo $goal->id; ?>" class="form-control">
                                        <option disabled selected>Please Choose</option>
                                        <?php for($i = $val_1; $i <= $val_2; $i++) { ?>
                                        <option value="<?php echo $i ?>"><?php echo $i ?></option>
                                        <? } ?>
                                    </select> 

<?php                
        }
    }
?>
                                </div>
                            </div> 
<?php
}
if(isset($_POST['submit'])) {
    if(count($insert_array) != count($goals)){
        $session->message('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Not Saved!</strong> All fields must be completed.</div>');
        redirect('client_home.php?client_id=' . $client->id . 'client_form=3');
        var_dump($insert_array);
    } else {
        $goal->save_goals($insert_array,$client->id);
        $session->message('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Goal Session Saved!</strong></div>');
        redirect('client_home.php?client_id=' . $client->id . '&client_form=3');
    }
}
?>  
                            <div class="form-group">
                                <a href="client_home.php?client_id=<?php echo $client->id;?>" class="btn btn-primary pull-left">Cancel</a>
                               <input type="submit" name="submit" class="btn btn-primary pull-right" value="Save">
                            </div>
                        </div>    
                    </div>
                </form>
               


                    
            </div>
        </div>

        
        
    
    
