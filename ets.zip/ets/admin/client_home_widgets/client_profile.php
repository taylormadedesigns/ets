
<?php 
if(!isset($_GET['client_id'])){
    redirect("index.php");
} else {    
    $client = User::find_by_id($_GET['client_id']);  
}

    if(isset($_POST['update_user'])){

        if($client) {
            
            $client->username = $_POST['username'];
            $client->first_name = $_POST['first_name'];
            $client->last_name = $_POST['last_name'];
            $client->day = $_POST['day'];
            $client->month = $_POST['month'];
            $client->year = $_POST['year'];
            $client->password = $_POST['password'];
            $client->updated_by = $session->user_id;
            
            if(empty($_FILES['user_image']['tmp_name'])) {
                $client->save();
                $session->message("<div id='my-alert' class='alert alert-success alert-dismissible'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div>");
                redirect("my_profile.php");
                
            } else {
                $client->unlink_photo();
                $client->set_file($_FILES['user_image']);
                $client->upload_photo();
                $client->save();
                $session->message("<div id='my-alert' class='alert alert-success alert-dismissible'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div>");
//                redirect("edit_user.php?id={$user->id}");
                redirect("client_home.php?client_id={$client->id}");
                
            }
            
        }
    
    }
?>

           
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                        <form action="" method="post" enctype="multipart/form-data"> 
                            <div class="col-xs-12 col-sm-4 text-center">
                                <div class="col-xs-4 col-xs-offset-4 col-sm-12 col-sm-offset-0">
                                    <img class="thumbnail" src="<?php echo $client->admin ? $client->image_path_and_placeholder() : "../clients/" . $client->image_path_and_placeholder();?>" alt="" width="100%" >
                                    <input type="file" name="user_image">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-8">
                                <?php echo $session->message(); ?>
                                <div class="form-group">
                                    <label for="first_name">First Name:</label>
                                    <input type="text" class="form-control" name="first_name" value="<?php echo $client->first_name;?>">
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name:</label>
                                    <input type="text" class="form-control" name="last_name" value="<?php echo $client->last_name;?>">
                                </div>
                                <div class="form-group">
                                    <label for="dob">DOB:</label>
                                    <div class="row">
                                        <div class="col-xs-4">
                                        
                                            <select class="form-control" name="day">
<?php for($x=1; $x < 32; $x++) { ?>
                                                <option value='<?php echo $x; ?>' <?php if($x == $client->day){echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                        </div>
                                        <div class="col-xs-4">
                                            <select class="form-control" name="month">
<?php for($x=1; $x < 13; $x++) { ?>
                                                <option value='<?php echo $x; ?>' <?php if($x == $client->month){echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                        </div>
                                        <div class="col-xs-4">
                                        
                                            <select class="form-control" name="year">
<?php 
echo $today = date('Y');
for($x = 1901; $x <= $today; $x++) {
?>
                                                <option value="<?php echo $x; ?>" <?php if($client->year == $x) {echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                     
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="username">Username/Email</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo $client->username;?>">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" name="password" value="<?php echo $client->password;?>" >
                                </div>
                                <div class="form-group pull-right">
                                    <input type="submit" class="btn btn-primary" name="update_user" value="Update">
                                </div>
                            </div>
                        </form>
<!--
                        <div class="col-xs-12 col-sm-4 text-center">
                            <h4>Latest Activity</h4>
                        </div>
-->
                    </div>
                </div>
            </div>
        
        
    
    
