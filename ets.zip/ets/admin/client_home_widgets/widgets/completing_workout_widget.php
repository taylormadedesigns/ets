
<script>
    var id = <?php echo $session->user_id; ?>
</script>    

<?php

    $user = User::find_by_id($session->user_id);
    $stat = Stats::find_all();
    if(isset($_GET['workout_id'])) { $workout_id = $_GET['workout_id']; } else { $workout_id = 0; }

    $ex_id = $set_id = $skipped = null;
    if(isset($_GET['skipped'])) {
        $skipped = $_GET['skipped'];
    }
    if(isset($_GET['exercise'])) {
        $ex_id = $_GET['exercise'];
    }
    if(isset($_GET['set'])) {
        $set_id = $_GET['set'];
    }
?>

<?php $workouts = Workouts::find_with_condition("WHERE id = " . $workout_id); ?> 
          

           
            
<?php if($workouts) : ?>



<div class="content-section-b">
    <div class="container">  
<?php foreach($workouts as $x) : ?>
       
        <div class="row">
            <div id="workout_name" class="col-xs-12" workout="<?php echo $x->id;?>">
                <h4 class="my-section-heading"><?php echo $x->workout_name; ?></h4>
            </div>
        </div>
           
            <?php if($x->workout_description) { ?>
        <div class="col-xs-12 exercise-row">
            <div class="col-xs-12">
                <p><b>Workout Description:</b></p>   
                <?php echo $x->workout_description; ?> 
            </div>
         
        </div> 
            <?php } ?>
        

<?php $exercises = Workout_exercises::find_with_condition("WHERE workout_id = " . $x->id); ?>
   
<?php if($x->workout_type == "circuit") : ?>
   
   <?php foreach($exercises as $e) : ?>
       
                
        <?php $set = Workout_sets_reps::find_sets("WHERE exercise_id = " . $e->id); ?>
        
    <?php endforeach; ?>
    
    <?php $i = 1; ?>
    
    <?php for ($total_sets = 1; $total_sets <= $set->sets; $total_sets++) : ?>
       
            <div class="col-xs-12 exercise-row set-row">
                <div class="col-xs-12">
                    <b><?php echo "Set " . $i; ?></b>  
                </div>
            </div>
            
        <?php foreach($exercises as $e) : ?>
            <?php $sets = Workout_sets_reps::find_with_condition("WHERE exercise_id = " . $e->id); ?>
                
            <?php foreach($sets as $s) : ?>
            <div class="col-xs-12 exercise-row">
<!--
                <?php if($e->image) { ?>
        <div class="col-xs-12 exercise-row">
                   <span class="label label-primary">View Exercise Video</span>
                     <?php echo $e->image; ?>
        </div>
        <?php } ?>     
-->
                <div class="col-xs-6">
                <?php echo $e->exercise . "<br>"; ?>
                </div>
                <div class="col-xs-3">Complete <?php echo $s->reps; ?> Reps</div>
                <div class="col-xs-3">Rest <?php echo $s->rest; ?> Seconds</div>
            </div>
            <?php endforeach; ?>
        <?php endforeach; ?>
        
        
        
    <?php $i++; ?>
    <?php endfor; ?>

<?php elseif ($x->workout_type == "sets"): ?>
 
     <?php foreach($exercises as $e) : ?>
        <div class="exercises-wrapper">
            <div class="row exercise-heading-wrapper"> 
                   <div class="col-xs-9 exercise-heading" exercise="<?php echo $e->id; ?>">
                       <?php echo $e->exercise; ?>
                   </div>   
                   <div class="col-xs-3 exercise-image">
                        <?php if($e->image) : ?>
    
                        <img src="<?php $e->image; ?>" alt="">
                        
                        <?php endif; ?>
                   </div>
            </div>



           <?php $sets = Workout_sets_reps::find_with_condition("WHERE exercise_id = " . $e->id); ?>
           
            <?php foreach($sets as $s) : ?>
                <?php for ($sets = 1; $sets <= $s->sets; $sets++) : ?>

                    <div class="col-xs-12 exercise-row <?php if($ex_id == $e->id && $set_id == $sets) { echo "completing_exercise"; } ?>">
                       
                        <div class="col-xs-3 set" set="<?php echo $sets; ?>">
                            Set <?php echo $sets; ?>
                        </div>
                        <div class="col-xs-3 reps" reps="<?php echo $s->reps; ?>">
                            <?php echo $s->reps; ?> x Reps
                        </div>
                        <div class="col-xs-3 rest" rest="<?php echo $s->rest ?>">
                            Rest for <?php echo $s->rest ?> x Seconds
                        </div>
                        <div class="col-xs-3">
                           
                            <?php if($ex_id == $e->id && $set_id == $sets && $sets != $s->sets) { ?>
                                
                                    <span class="pull-right">
                                        <a id="open_here" href="completing_workout.php?workout_id=<?php echo $workout_id; ?>&exercise=<?php echo $e->id;?>&set=<?php echo $sets+1; ?>#open_here" class="btn btn-xs btn-default next_exercise">Next</a>

                                    </span>
                                    
                            
                            <?php } else if ($ex_id == $e->id && $set_id == $sets && $set_id == $s->sets) { ?>
                                
                                    <span class="pull-right">
                                        <a id="open_here" href="completing_workout.php?workout_id=<?php echo $workout_id; ?>&exercise=<?php echo $e->id+1;?>&set=1#open_here" class="btn btn-xs btn-default next_exercise">Next</a>
                                    </span>
                            
                            <?php } else if (($ex_id == $e->id && $set_id > $sets) || ($ex_id > $e->id)) { ?>
                                   
                                    <span class="btn btn-xs btn-success pull-right">Completed</span>
                                    
                            <?php } ?>
                            <?php if($ex_id > $e->id) { ?>
                                    <span id="open_here"></span>
                            <?php } ?>
                            
                        </div>
                    </div>

                <?php endfor;  ?>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>  

<?php endif; ?>

<?php endforeach; ?>  
    
            <div class="col-xs-12 complete-buttons">
            <a href="workouts.php" onclick="confirm('Giving up is not an option! Are you sure you want to quit your workout?')" class="btn btn-primary">Cancel</a>

                <a href="workouts.php?complete=yes&workout_id=<?php echo $workout_id; ?>&user_id=<?php echo $session->user_id; ?>" class="btn btn-primary pull-right" onclick="confirm('Are you sure you want to complete your workout?')">Complete</a>
            
        </div>

    </div>
</div>

<?php endif; ?>





