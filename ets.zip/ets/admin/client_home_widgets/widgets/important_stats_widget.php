            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                       
                       <?php echo $session->message();?>
                       
                        <div class="col-xs-12 text-center">
                            <h4 class="my-section-heading">Important Statistics</h4>
                            <div class="col-xs-3 col-sm-3 col-md-2 col-md-offset-2">
                                <img class="img-responsive" src="img/statSymbols_bp.png" alt="">
                                <h2>
                                
<?php 
    $user_bp    = Stats::find_stat_by_result(2);
    $user_bp_d  = Stats::find_stat_by_result(3);
                                    
    if($user_bp){
        echo $user_bp->body_stat_result . " / " . $user_bp_d->body_stat_result;
    } else { ?>
                                
                                <a href="" class="btn btn-primary">Add</a>
                                
<?php } ?>
                                
                                </h2>
                            </div>
                            <div class="col-xs-3 col-sm-3 col-md-2">
                                <img class="img-responsive" src="img/statSymbols_waist.png" alt="">
                                <h2>
                                    
<?php 
    $user_waist  = Stats::find_stat_by_result(8);                                
                                    
    if($user_waist){
        echo $user_waist->body_stat_result . " cm";
    } else { ?>
                                
                                <a href="body_stats_new.php?id=<?php echo $user_id->id; ?>" class="btn btn-primary">Add</a>
                                
<?php } ?>                                    
                                    
                                </h2>
                            </div>
                            <div class="col-xs-3 col-sm-3 col-md-2">
                                <img class="img-responsive" src="img/statSymbols_fat.png" alt="">
                                <h2>
                                    
<?php 
    $user_fat  = Stats::find_stat_by_result(6);                                
                                    
    if($user_fat){
        echo $user_fat->body_stat_result . " %";
    } else { ?>
                                
                                <a href="body_stats_new.php?id=<?php echo $user_id->id; ?>" class="btn btn-primary">Add</a>
                                
<?php } ?>                                     
                                    
                                    
                                </h2>
                            </div>
                            <div class="col-xs-3 col-sm-3 col-md-2">
                                <img class="img-responsive" src="img/statSymbols_heart.png" alt="">
                                <h2>
                                    
<?php 
    $user_hr  = Stats::find_stat_by_result(6);                                 
    
    if($user_hr){
        echo $user_hr->body_stat_result . " bpm";
    } else { ?>
                                
                                <a href="body_stats_new.php?id=<?php echo $user_id->id; ?>" class="btn btn-primary">Add</a>
                                
<?php } ?>                                    
                                    
                                    
                                </h2>
                            </div>
                        </div>
<!--
                        <div class="col-xs-12 col-sm-4 text-center">
                            <h4>Latest Activity</h4>
                        </div>
-->
                    </div>
                </div>
            </div>



