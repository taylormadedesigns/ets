<?php

    $user = User::find_by_id($session->user_id);
    $recipe = Recipes::find_all();

    if(isset($_GET['action']) && isset($_GET['recipe_id'])) {
        if($_GET['action'] == "add-to-favourites") {
            if(isset($_GET['saved_id'])) { 
                $saved_recipes->id = $_GET['saved_id'];
            }
            $saved_recipes->recipe_id = $_GET['recipe_id'];
            $saved_recipes->client_id = $user->id;
            $saved_recipes->studio_id = $user->studio_id;
            $saved_recipes->save();
            redirect('?recipe_id=' . $_GET['recipe_id']);
        }
        if($_GET['action'] == "remove-from-favourites") {
            if(isset($_GET['saved_id'])) {
                $saved_recipes->id = $_GET['saved_id'];    
                $saved_recipes->recipe_id = $_GET['recipe_id'];
                $saved_recipes->delete();
                redirect('?recipe_id=' . $_GET['recipe_id']);
            }
        }
    }
    if(isset($_GET['action']) && isset($_GET['recipe_id'])) {
        if($_GET['action'] == "save-to-menu") {
            if(isset($_GET['saved_id'])) {
                $menu_recipes->id = $_GET['saved_id'];    
            }
            $menu_recipes->recipe_id = $_GET['recipe_id'];
            $menu_recipes->client_id = $user->id;
            $menu_recipes->studio_id = $user->studio_id;
            $menu_recipes->save();
            redirect('?recipe_id=' . $_GET['recipe_id']);
        }
        if($_GET['action'] == "remove-from-menu") {
            if(isset($_GET['saved_id'])) {
                $menu_recipes->id = $_GET['saved_id'];    
                $menu_recipes->recipe_id = $_GET['recipe_id'];
                $menu_recipes->delete();
                redirect('?recipe_id=' . $_GET['recipe_id']);
            }
        }
    }
?>         
           
            
            
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                    
<?php if (isset($_GET['recipe_id'])) { ?>
   
                <?php $recipe = Recipes::find_by_id($_GET['recipe_id']); ?>
                    
                    <div class="col-xs-12">
                            <h4 class="my-section-heading"><?php echo $recipe->name; ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <img class="thumbnail" src="img/<?php echo !$recipe->image ? "recipe-no-img.jpg" : $recipe->image; ?>" alt="" width="100%">
                    </div>
                    <div class="col-sm-6">
                        <h4>PREP: <?php echo $recipe->prep; ?> mins </h4>
                        <h4>COOK: <?php echo $recipe->cook; ?> mins </h4>
                        <h4>DIFFICULTY: <?php echo $recipe->level; ?> / 5</h4>
                        <p><i>Uploaded by <?php $user = User::find_by_id($recipe->uploaded_by); echo $user->first_name; ?></i></p>
                        <div class="col-xs-12 text-center">
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    <li id="ingredients" class="page-item active">
                                        <a class="page-link">Ingredients</a>
                                    </li>
                                    <li id="method" class="page-item">
                                        <a class="page-link">Method</a>
                                    </li>
<!--
                                    <li id="ingredients" class="page-item<?php if($_GET['q'] != "method") {echo " active"; }?>"><a class="page-link" href="?recipe_id=<?php echo $recipe->id; ?>&q=ingredients#ingredients">Ingredients</a></li>
                                    <li id="method" class="page-item<?php if($_GET['q'] == "method") {echo " active"; }?>"><a class="page-link" href="?recipe_id=<?php echo $recipe->id; ?>&q=method#method">Method</a></li>
-->
                                </ul>
                            </nav>
                        </div>
                        <div class="ingredients">
                            <?php $ingredients = Recipe_ingredients::find_by_recipe_id($recipe->id); ?>
                                
                                <p><u><b>Ingredients</b></u></p>
                                
                                <table class="table">
                                    
                                <?php foreach ($ingredients as $i) { ?>
                                
                                
                                <tr>
                                    <td><?php echo $i->qty; ?> <?php echo $i->qty_type; ?></td> 
                                    <td><?php echo ucfirst($i->ingredient); ?></td>
                                </tr>
                                
                                
                                <?php } ?>
                                
                                </table>
                        </div>
                        <div class="method">
                            <?php $method = Recipe_method::find_by_recipe_id($recipe->id); ?>
                                
                                <p><u><b>Method</b></u></p>
                                
                                <table class="table">
                                    
                                <?php foreach ($method as $m) { ?>
                                
                                
                                <tr>
                                    <td>Step <?php echo $m->step; ?></td> 
                                    <td><?php echo ucfirst($m->method); ?></td>
                                </tr>
                                
                                
                                <?php } ?>
                                
                                </table>
                        </div>


                        
                        <span class="pull-right">
                            <?php $saved = $saved_recipes->find_by_recipe_id($session->studio_id, $session->user_id, $recipe->id); ?>
                            <?php $menu = $menu_recipes->find_by_recipe_id($session->studio_id, $session->user_id, $recipe->id); ?>

                            <a href='?recipe_id=<?php echo $recipe->id; ?><?php echo $saved ? "&action=remove-from-favourites" : "&action=add-to-favourites"; ?><?php echo $saved ? "&saved_id=" . $saved->id : false; ?>' id="add-to-favourites" class="glyphicon glyphicon-heart recipe-icons <?php echo !$saved ? "primary" : "red"; ?>" data-toggle="tooltip" role="tooltip" data-placement="top" title="<?php echo !$saved ? "Save to favourites" : "Remove from favourites"; ?>"></a> 
                            
                            <a href='?recipe_id=<?php echo $recipe->id; ?><?php echo $menu ? "&action=remove-from-menu" : "&action=save-to-menu"; ?><?php echo $menu ? "&saved_id=" . $menu->id : false; ?>' id="save-to-menu" class="glyphicon glyphicon-cutlery recipe-icons <?php echo !$menu ? "primary" : "red"; ?>" data-toggle="tooltip" role="tooltip" data-placement="top" title="<?php echo !$menu ? "Add meal to menu" : "Remove meal from menu"; ?>"></a>
                        </span>
                        <div class="col-xs-12">
                            <a href="recipes.php" class="btn btn-default">Back to Recipes</a>
                        </div>
                    </div>
                    
    
    
<?php } else { ?>
                    <div class="col-xs-12">
                            <h4 class="my-section-heading">Recipes</h4>
                        </div>
                    </div>
                    
                    
                <?php echo $session->message(); ?>
                <?php $i = 1;?>
                <?php foreach ($recipe as $r) : ?>
                        
                        <div class="col-sm-3">
                            <img src="img/recipe-no-img.jpg" alt="" width="100%">
                            <a href="recipes.php?recipe_id=<?php echo $r->id; ?>"><h3><?php echo ucwords($r->name); ?></h3></a>
                            <p>DIFFICULTY LEVEL <?php echo $r->level; ?> / 5</p>
                        </div>
                
                <?php endforeach; ?>
                
<?php } ?>

                </div>
            </div>




