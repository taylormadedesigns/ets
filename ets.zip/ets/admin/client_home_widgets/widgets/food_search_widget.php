<?php
    $user = User::find_by_id($session->user_id);
    $today = date('Y-m-d');
    if(isset($_GET['date'])) {
        $date = $_GET['date'];
    }
?>
<?php if (isset($_GET['delete'])) {
    
    $food_diary->id = $_GET['delete'];
    $food_diary->id;
    $food_diary->delete();
    redirect('food_diary.php?date=' . $date . '#diaryhead');
} ?>



<?php !isset($_GET['meal']) ? $meal = 1 : $meal = $_GET['meal']; ?>
<?php 
if(isset($_POST['submit_to_food_diary'])) {
    
    $foods_found = Foods::find_by_food_id($_GET['insert_food_id']);
//    $one_percent_kj = Foods::get_kj($_GET['insert_food_id']);
    
    if (preg_match('#\((.*?)\)#', $_POST['qty'], $match)){
   
        echo $qty = $str = preg_replace('/[^0-9.]+/', '', $match[1]);

    } else {
        echo $qty = 1;
    }
        
    $food_diary->food_id    = $_GET['insert_food_id'];
    $food_diary->serves     = $_POST['serves'];
    $food_diary->measure    = $_POST['qty'];
    $food_diary->meal       = $_POST['meal'];
    $food_diary->date       = $date;
    $food_diary->client_id  = $session->user_id;

    
    $food_diary->create();
    
    redirect('food_diary.php?date=' . $date);
}
?>
<?php if(isset($_POST['submit'])) : ?>
    <?php redirect('food_diary.php?search=1&meal=' . $meal . '&date=' . $date . '&q=' . $_POST['food_search']); ?>
<?php endif; ?>


<div class="container">    
    <h4 class="my-section-heading">Food Search</h4>
                
                
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <div class="panel-row">
                            <form action="" class="form-inline" method="post">
                                <div class="form-group">
                                    <input name="food_search" type="text" class="form-control" value="<?php if(isset($_GET['q'])) {echo $_GET['q'];} ?>" length="255" placeholder="Search food database">     
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary pull-right" name="submit" value="Search">   
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>    
        </div>



<?php if(isset($_GET['q'])) : ?>
    
    
    <?php $foods = Foods::find_by_food($_GET['q']); ?>
    
    
        <div class="panel panel-primary">
            <div class="panel-body">

               <div class="panel-row">
                    <div class="col-xs-8 col-sm-6 panel-row-question">
                        <b>Food</b> 
                    </div>
                    <div class="hidden-xs col-sm-3 panel-row-question">
                        <span class="pull-right">
                            <b>Calories per Serve</b>
                        </span>
                    </div>
                    <div class="col-xs-4 col-sm-3 panel-row-question">
                        
                    </div>
                </div>
                <div class="panel-divider"></div>
        <?php foreach($foods as $food) : ?>
                
                <div class="panel-row">
                    <div class="col-xs-8 col-sm-6 panel-row-question">
                        <?php echo $food->food_name . "<br>"; ?> 
                    </div>
                    <div class="hidden-xs col-sm-3 panel-row-question">
                        <span class="pull-right"><?php echo $food->cal; ?> Cals / <?php $per = explode(',', $food->amount); echo ucfirst($per[0]); ?></span>
                    </div>
                    <div class="col-xs-4 col-sm-3 panel-row-question">
                        <a href="?search=1&meal=<?php echo $meal; ?>&food_id=<?php echo $food->food_id; ?>&date=<?php echo $date; ?>" class="btn btn-primary pull-right">Select</a>
                    </div>
                </div>
                <div class="panel-divider"></div>
        <?php endforeach; ?>

            </div>
        </div>
    
<?php endif; ?>

<?php if(isset($_GET['food_id'])) : ?>

<?php $foods_found = Foods::find_by_food_id($_GET['food_id']); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <div class="panel-row text-center">
                            <div class="col-xs-12 panel-row-question">
                                <?php echo $foods_found->food_name; ?>
                            </div>
                        </div>
                        <div class="panel-divider"></div>
                        <div class="panel-row text-center">  
                            <div class="col-xs-3 panel-row-question">
                                <b><?php echo $foods_found->protein; ?>g</b> Protein
                            </div>
                            <div class="col-xs-3 panel-row-question">
                                <b><?php echo $foods_found->carbs; ?>g</b> Carbs
                            </div>
                            <div class="col-xs-3 panel-row-question">
                                <b><?php echo $foods_found->fat; ?>g</b> Fats
                            </div>
                            <div class="col-xs-3">
                                <b><?php echo $foods_found->cal; ?></b> Calories
                            </div>
                        </div>
                        <div class="panel-row text-center">
                            <b>Per Serving: </b><?php echo $foods_found->default_amount;?>
                        </div>
                        <div class="panel-divider"></div>


                        <form action="?search=1&insert_food_id=<?php echo $foods_found->food_id; ?>&date=<?php echo $date; ?>" method="post">

                            <div class="panel-row">
                                <div class="col-xs-12 panel-row-question">
                                    QTY: 
                                    
                                    <?php 
                                    
                                    ?>

                                    <select name="qty" id="" class="form-control">

<?php 
$amount_array_values = $foods_found->amount;                                       
//$amount_array_values = str_replace("serving,","serving - ", $foods_found->amount);
$amount_array = explode(',,',$amount_array_values); 

foreach($amount_array as $amount) {

    if (preg_match('#\((.*?)\)#', $amount, $match)){
//echo "<option value='" . $amount . "'>" . $match[1] . "</option>";
        $brackets = true;

    } else {
        $brackets = false;
    }

if(($amount != "oz") && $amount != "serving" && $amount != "fl. oz") {
    echo "<option value='" . $amount . "'>" . $amount . "</option>";
}
    
}                                       
                                        
?>

                                    </select>
                                </div>
                            </div>
                            <div class="panel-row">
                                <div class="col-xs-12 panel-row-question">
                                    Serves                    
                                        <select name="serves" id="" class="form-control">
                                           <?php for($i = 0.5; $i < 1001; $i+=0.5) : ?>

                                                <option value="<?php echo $i; ?>" <?php if($i == 1) {echo "selected";} ?>><?php echo $i; ?></option>

                                            <?php endfor; ?>
                                        </select> 

                                </div>
                            </div>
                            <div class="panel-row">
                                <div class="col-xs-12 panel-row-question">
                                    Meal               
                                        <select name="meal" id="" class="form-control">
                                           <?php for($i = 1; $i < 7; $i++) : ?>

                                                <option value="<?php echo $i; ?>" <?php if($meal == $i){echo "selected";} ?>>Meal <?php echo $i; ?></option>

                                            <?php endfor; ?>
                                        </select> 
                                </div>
                            </div>
                            <div class="panel-divider"></div>
                            <div class="panel-footer">
                                <input type="submit" name="submit_to_food_diary" class="btn btn-primary" value="Add">
                            </div>   


                        </form>

                    </div>
                </div>
            </div>
        </div>
<?php endif; ?>




</div>





