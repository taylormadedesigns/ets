<?php
    $user = User::find_by_id($session->user_id);
    $today = date('Y-m-d');
    if(isset($_GET['date'])) {
        $date = $_GET['date'];
    } else {
        $date = null;
    }
?>

<div class="container">    
    <h4 id="diaryhead" class="my-section-heading">Food Diary</h4>
        <div class="text-center">
            <div class="nutrient-totals">
                <span class="">
                    <p><b>Daily Goals:</b></p>
                    <div class="row nutrient-goal-font">
                        <div class="col-xs-3">
                           <?php
                            
//                            Food_diary::food_totals($session->user_id,$date,'cal') - 1800; 
                            
                            $starting_weight = Goals::food_intake_requirements($session->studio_id, $session->user_id,9);
                            $goal_weight = Goals::food_intake_requirements($session->studio_id, $session->user_id,10);
                            $weekly_goal = Goals::food_intake_requirements($session->studio_id, $session->user_id,11);
                            $activity_level = Goals::food_intake_requirements($session->studio_id, $session->user_id,12);
                            
                            $user_height = Stats::find_stat_by_result(4);
                            
                            if(!$user->day || !$user->month || !$user->year) {
                                echo "<p><a class='btn btn-xs btn-default' href='my_profile.php'>UPDATE YOUR D.O.B</a></p>";
                            } else if(!$user_height) {
                                echo "<p><a class='btn btn-xs btn-default' href='body_stats_new.php?id={$session->user_id}'>UPDATE YOUR HEIGHT</a></p>";
                            } else if (!$starting_weight || !$goal_weight || !$activity_level) {
                                echo "<p><a class='btn btn-xs btn-default' href='goals_new.php'>UPDATE YOUR GOALS</a></p>";
                            } else {
                                echo $food_diary->get_target_calories() ? round($food_diary->get_target_calories()) : "<p><a class='btn btn-xs btn-default' href='my_profile.php'>UPDATE YOUR GENDER</a";
                            }
                            
                            
                            
                            ?> 
                        </div> 
                        <div class="col-xs-3">
                            <?php echo round($food_diary->get_target_protein()) ?>g
                        </div> 
                        <div class="col-xs-3">
                            <?php echo round($food_diary->get_target_carbs()) ?>g
                        </div> 
                        <div class="col-xs-3">
                            <?php echo round($food_diary->get_target_fats()) ?>g
                        </div>   
                    </div>
                    <div class="row nutrient-type-heading">
                        <div class="col-xs-3">
                            CALORIES
                        </div> 
                        <div class="col-xs-3">
                            PROTEIN
                        </div> 
                        <div class="col-xs-3">
                            CARBOHYDRATE
                        </div> 
                        <div class="col-xs-3">
                            FAT
                        </div>    
                    </div>
                    <div class="row nutrient-consumed">
                        <div class="col-xs-3">
                           
                           <?php 
                            if((round($food_diary->get_target_calories() - Food_diary::food_totals($session->user_id,$date,'cal'))) < 0) {
                                
                                echo "<span class='nutrient_red'>+" . round($food_diary->get_target_calories() - Food_diary::food_totals($session->user_id,$date,'cal')) . "</span>";
    
                            } else {
                                echo "<span class='nutrient_green'>-" . round($food_diary->get_target_calories() - Food_diary::food_totals($session->user_id,$date,'cal')) . "</span>";
                            }
                            ?> 
                            
                        </div> 
                        <div class="col-xs-3">
                            
                            <?php 
                            if((round($food_diary->get_target_protein() - Food_diary::food_totals($session->user_id,$date,'protein'))) < 0) {
                                
                                echo "<span class='nutrient_red'>+" . round($food_diary->get_target_protein() - Food_diary::food_totals($session->user_id,$date,'protein')) . "</span>";
    
                            } else {
                                
                                echo "<span class='nutrient_green'>-" . round($food_diary->get_target_protein() - Food_diary::food_totals($session->user_id,$date,'protein')) . "</span>";
                            }
                            ?> 
                            
                        </div> 
                        <div class="col-xs-3">
                            
                            <?php 
                            if((round($food_diary->get_target_carbs() - Food_diary::food_totals($session->user_id,$date,'carbs'))) < 0) {
                                
                                echo "<span class='nutrient_red'>+" . round($food_diary->get_target_carbs() - Food_diary::food_totals($session->user_id,$date,'carbs')) . "</span>";
    
                            } else {
                                echo "<span class='nutrient_green'>-" . round($food_diary->get_target_carbs() - Food_diary::food_totals($session->user_id,$date,'carbs')) . "</span>";
                            }
                            ?> 
                        </div> 
                        <div class="col-xs-3">
                            
                            <?php 
                            if((round($food_diary->get_target_fats() - Food_diary::food_totals($session->user_id,$date,'fat'))) < 0) {
                                
                                echo "<span class='nutrient_red'>+" . round($food_diary->get_target_fats() - Food_diary::food_totals($session->user_id,$date,'fat')) . "</span>";
    
                            } else {
                                echo "<span class='nutrient_green'>-" . round($food_diary->get_target_fats() - Food_diary::food_totals($session->user_id,$date,'fat')) . "</span>";
                            }
                            ?> 
                        </div>  

                    </div>
                    <h4 class="my-section-heading"></h4>
                </span>    
            </div>  
           
            <nav aria-label="Page navigation">
<?php if ($date !== $today) : ?>
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d'); ?>#diaryhead">Today</a></li>
                </ul>
<?php endif; ?>
                <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d', strtotime($date . '-1 days')); ?>#diaryhead" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                      </a>
                    </li>
                    <li class="page-item">
                    
<?php if ($date == $today) { ?>
    
    <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d'); ?>#diaryhead">Today</a>
    
<?php } else if ($date == date('Y-m-d', strtotime($today . " -1 days"))) { ?>
    
    <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d', strtotime($today . " -1 days")); ?>#diaryhead">Yesterday</a>
    
<?php } else if ($date == date('Y-m-d', strtotime($today . " +1 days"))){ ?>
    
    <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d', strtotime($today . " +1 days")); ?>#diaryhead">Tomorrow</a>
    
<?php } else { ?>
    
    <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo $date; ?>#diaryhead"><?php echo date('d-m-Y', strtotime($date));?></a>
    
<?php } ?>
                    
                    
                    
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="?id=<?php echo $session->user_id ?>&date=<?php echo date('Y-m-d', strtotime($date . '+1 days')); ?>#diaryhead" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only">Next</span>
                      </a>
                    </li>
                </ul>
                <ul class="pagination">
                    <li class="page-item"><a id="edit_food_diary" class="page-link pull-right" href="#diaryhead">Edit</a></li>
                </ul>
            </nav>      
        </div> 
                
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-primary">
                    <div class="panel-body">
                       
<?php for($meal = 1; $meal < 7; $meal++) : ?>
                       
                        <div class="panel-row meal-header">
                            Meal <?php echo $meal; ?> <a href="?search=1&meal=<?php echo $meal; ?>&date=<?php echo $date; ?>" class="btn btn-sm btn-primary pull-right">Add to Meal <?php echo $meal; ?></a>
                        </div>
                        
<?php if (isset($_GET['date'])) : ?>

<?php $food_diary_found = Food_diary::find_by_food_date($session->user_id,$_GET['date'],$meal,$session->user_id); ?>
                     
    <?php if($food_diary_found) { ?>
                     
        <?php foreach ($food_diary_found as $f) : ?>
                <?php $food_stats_from_db = Foods::find_by_food_id($f->food_id); ?>
                           
                            <div class="panel-row">
                                <div class="col-xs-2">
                                    <?php echo $f->measure; ?>
                                </div>
                                <div class="col-xs-7 col-sm-6 food">
                                    <?php  echo $food_stats_from_db->food_name; ?>   
                                </div>
                                <div class="col-xs-3 col-sm-4 cals">
                                    <span class="pull-right text-center">
                                    <div class="row">
                                        <div class="col-sm-3 hidden-xs">
                                            Protein
                                        </div>
                                        <div class="col-sm-3 hidden-xs">
                                            Carbs
                                        </div>
                                        <div class="col-sm-3 hidden-xs">
                                            Fats
                                        </div>
                                        <div class="col-xs-3">
                                            Cals
                                        </div>  
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-3 hidden-xs">
                                            <?php echo round(($f->measure * Foods::get_value($f->food_id, 'protein')), 0); ?>g
                                        </div>
                                        <div class="col-sm-3 hidden-xs">
                                            <?php echo round(($f->measure * Foods::get_value($f->food_id, 'carbs')), 0); ?>g
                                        </div>
                                        <div class="col-sm-3 hidden-xs">
                                            <?php echo round(($f->measure * Foods::get_value($f->food_id, 'fat')), 0); ?>g
                                        </div>
                                        <div class="col-xs-3">
                                            <?php echo round(($f->measure * Foods::get_value($f->food_id, 'cal')), 0); ?>
                                        </div>  
                                    </div>
                                </span>   
                                </div>  
                                <div class="col-xs-3 col-sm-2 food_delete_button">
                                    <a href="?search=1&meal=<?php echo $meal; ?>&delete=<?php echo $f->id; ?>&date=<?php echo $date; ?>" class="btn btn-sm btn-danger pull-right">Delete</a>    
                            </div>
                            </div>
                            <div class="panel-divider"></div>
                            
        <?php endforeach; ?>
 
    
    <?php } else { ?>    

                            <div class="panel-row">
                                <div class="col-xs-12">
                                    No foods entered for this meal
                                      
                                </div>
                                 
                                     
                            </div>
                            <div class="panel-divider"></div>

<?php } ?>

<?php endif; ?>
                       
<?php endfor; ?>  
                    <div class="panel-row">
                        <div class="col-xs-12">
                           
                           
                        
                        <span class="pull-right"><b>Daily Totals:</b> Calories 
                        
                        <?php echo Food_diary::food_totals($session->user_id,$date,'cal'); ?> | 
                        
                          Protein
                          
                          <?php echo Food_diary::food_totals($session->user_id,$date,'protein'); ?>g | 
                          
                           Carbs 
                          
                          <?php echo Food_diary::food_totals($session->user_id,$date,'carbs'); ?>g | 
                          
                           Fats 
                          
                          <?php echo Food_diary::food_totals($session->user_id,$date,'fat'); ?>g | 
                          
                          </span>   
                        </div>


                    </div>
                    <div class="panel-divider"></div> 
                    </div>
                    
                    <div class="panel-footer">
                        <a href="?search=1&date=<?php echo $date; ?>" class="btn btn-primary">Add to Diary</a>
                    </div>
                    
                  
                    
                </div>
            </div>    
        </div>
</div>




