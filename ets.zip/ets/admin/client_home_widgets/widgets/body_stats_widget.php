<?php

    $client = User::find_by_id($_GET['client_id']);
    $stat = Stats::find_all();

?>

    <div class="panel panel-default">
        <div class="panel-body">
<?php 
$find_stat = 1;                    
foreach($stat as $stats){
                
                  $stat_result = Stats::find_stat_by_result($find_stat,$client->id);
         
$find_stat ++;   
?>
<?php if ($stats->body_stat == "bp"){?> 
                    

            <div class="panel-row">
                <div class="col-sm-6 panel-row-question">
                    <b><?php echo $stats->body_stat_label;?></b>
                </div>
                <div class="col-sm-2 panel-row-question">

                <?php echo $stat_result ? $stat_result->body_stat_result : false; ?>
                <?php $stat_result = Stats::find_stat_by_result(3,$client->id); ?>
                <?php echo $stat_result ? " / " . $stat_result->body_stat_result : false; ?>

                </div>
                <div class="col-sm-2 panel-row-question">
                
                <?php echo $stat_result ? Stats::stat_comparisons($stats->body_stat,$stat_result->body_stat_result) : false; ?>

                </div>
                <div class="col-sm-2 panel-row-question">
                    <a href="body_stats.php?client_id=<?php echo $client->id; ?>&history=1&stat=<?php echo $stats->id;?>" class="btn btn-xs btn-default pull-right">View History</a>
                </div>
            </div>
            <div class="panel-divider"></div>

 
<?php } else if ($stats->body_stat == "bp_d") {
    
} else { ?>
                   
                                                     

            <div class="panel-row">
                <div class="col-sm-6 panel-row-question">
                    <b><?php echo ucfirst($stats->body_stat_label);?></b>
                </div>
                <div class="col-sm-2 panel-row-question">

                <?php echo $stat_result ? ucfirst($stat_result->body_stat_result) : false; ?>


                </div>
                <div class="col-sm-2 panel-row-question">
                
                <?php echo $stat_result ? Stats::stat_comparisons($stats->body_stat,$stat_result->body_stat_result) : false; ?>
            

                </div>
                <div class="col-sm-2 panel-row-question">
                    <a href="body_stats.php?client_id=<?php echo $client->id; ?>&history=1&stat=<?php echo $stats->id;?>" class="btn btn-xs btn-default pull-right">View History</a>
                </div>
            </div>
            <div class="panel-divider"></div>

              
<?php }} ?>

        <div class="panel-footer">
            <a href="?client_id=<?php echo $client->id; ?>&new=stats" class="btn btn-primary">Edit</a>
        </div>
    </div> 








