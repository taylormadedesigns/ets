<?php
    $user           = User::find_by_id($session->user_id);
    $goals          = Goals::find_all();
    $client_goals   = Goals::find_all_client_goal_answers(1, $session->user_id);


?>

    <div class="panel panel-primary">
        <div class="panel-body">
<?php foreach ($goals as $goal) : ?>

            <div class="panel-row">

                <div class="col-sm-6 panel-row-question">
                    <b><?php echo $goal->goal; ?></b>
                </div>
                <div class="col-sm-6 panel-row-question">

<?php $answer = Goals::get_client_goal_answer_by_answer_id(1, $session->user_id, $goal->id); ?>
<?php echo $answer->goals_answer; ?>

                </div>





            </div>
            <div class="panel-divider"></div>


<?php endforeach; ?>
        </div>
        <div class="panel-footer">
            <a href="goals_new.php" class="btn btn-primary">Set New Goals</a>
        </div>
    </div> 