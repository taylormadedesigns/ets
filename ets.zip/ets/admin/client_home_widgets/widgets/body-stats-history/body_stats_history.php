<?php

    $client             = User::find_by_id($_GET['client_id']);
    $stat               = Stats::find_all();
    $goal_weight_type   = Goals::get_client_goal_weight(1,$client->id,3);
    $goal_weight        = Goals::get_client_goal_weight(1,$client->id,4);
    $goal_weight_type   = $goal_weight_type ? $goal_weight_type->goals_answer : false;
    $goal_weight        = $goal_weight_type ? $goal_weight->goals_answer : false;
?>
    
    <?php if(isset($_GET['stat'])) {
    $stat_id           = Stats::find_by_id($_GET['stat']);
    
    $stat_result = Stats::find_stat_history($stat_id->id,20);

    ?>
    *Seeing last 20 results
    <?php if($stat_result) { ?>
    
        <script type="text/javascript">
          google.charts.load('current', {'packages':['corechart']});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {
            var data = google.visualization.arrayToDataTable([

            ['Date', 'Weight (kg)', <?php echo $_GET['stat'] == 4 ? "Goal" : false; ?>],

        <?php 
        $i = 0;
        foreach($stat_result as $r) {
            $stat_result = Stats::find_stat_by_result($_GET['stat']);
            

            ?>



              ['<?php echo date('d/m/Y', strtotime($r->mod_date)); ?>',  <?php echo $r->body_stat_result; ?>, <?php echo $_GET['stat'] == 4 ? $goal_weight : false; ?>],

            <?php
        }
        ?>
                ]);

            var options = {
              title: '<?php echo $stat_id->body_stat_label; ?>',
              curveType: 'function',
              legend: { position: 'bottom' }
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

            chart.draw(data, options);
          }
        </script>
        
        
            <div id="curve_chart" style="width: 100%; height: 400px;"></div>   
     
<?php } else {
   echo "<div class='col-xs-12 text-center' style='margin: 50px;'><span class='alert alert-danger'>Nothing recorded for this stat.</span></div>"; 
}  ?>
    
<?php } else {
    
}  ?>
   
<div class="panel panel-primary">
    <div class="panel-body">
<?php 
$find_stat = 1;                    
foreach($stat as $stats){
                
                  $stat_result = Stats::find_stat_by_result($find_stat,$client->id);
         
$find_stat ++;   
?>
<?php if ($stats->body_stat == "bp"){?> 
                    

        <div class="panel-row">
            <div class="col-sm-6 panel-row-question">
                <b><?php echo $stats->body_stat_label;?></b>
            </div>
            <div class="col-sm-2 panel-row-question">

            <?php echo $stat_result ? $stat_result->body_stat_result : false; ?>
            <?php $stat_result = Stats::find_stat_by_result(3,$client->id); ?>
            <?php echo $stat_result ? " / " . $stat_result->body_stat_result : false; ?>

            </div>
            <div class="col-sm-2 panel-row-question">

            <?php echo $stat_result ? Stats::stat_comparisons($stats->body_stat,$stat_result->body_stat_result) : false; ?>

            </div>
            <div class="col-sm-2 panel-row-question">
                <a href="body_stats.php?id=<?php echo $session->user_id; ?>&history=1&stat=<?php echo $stats->id;?>" class="btn btn-xs btn-default pull-right">View History</a>
            </div>
        </div>
        <div class="panel-divider"></div>

 
<?php } else if ($stats->body_stat == "bp_d") {
    
} else { ?>
                   
                                                     

        <div class="panel-row">
            <div class="col-sm-6 panel-row-question">
                <b><?php echo ucfirst($stats->body_stat_label);?></b>
            </div>
            <div class="col-sm-2 panel-row-question">

            <?php echo $stat_result ? ucfirst($stat_result->body_stat_result) : false; ?>


            </div>
            <div class="col-sm-2 panel-row-question">

            <?php echo $stat_result ? Stats::stat_comparisons($stats->body_stat,$stat_result->body_stat_result) : false; ?>


            </div>
            <div class="col-sm-2 panel-row-question">
                <a href="body_stats.php?id=<?php echo $session->user_id; ?>&history=1&stat=<?php echo $stats->id;?>" class="btn btn-xs btn-default pull-right">View History</a>
            </div>
        </div>
        <div class="panel-divider"></div>

              
<?php }} ?>

        <div class="panel-footer">
            <a href="body_stats_new.php?id=<?php echo $user_id->id; ?>" class="btn btn-primary">Edit</a>
        </div>
    </div> 
</div>








