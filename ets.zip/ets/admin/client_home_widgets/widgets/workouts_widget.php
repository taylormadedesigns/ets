<?php

    $user = User::find_by_id($session->user_id);
    $stat = Stats::find_all();

?>
<?php $filter               = isset($_GET['filter']) && !empty($_GET['filter']) ? $_GET['filter'] : null; ?>
<?php $workouts             = Workouts::find_all(); ?>
<?php $workout_category     = Workout_category::find_all(); ?>
<?php $workout_condition    = isset($filter) ? " AND workout_category = " . $filter : null; ?>
<?php $workouts             = Workouts::find_with_condition("WHERE studio_id = {$session->studio_id}" . $workout_condition); ?>          
           
            
            
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <form class="form" action="">
                                    <select class="pull-right" name="filter" id="" onchange="this.form.submit()">
                                        <option value="" <?php if($filter == null) { echo "selected"; } ?>>Filter workouts by... </option>
                                        
                                        
                                        <?php foreach ($workout_category as $w) { ?>

                                             <option value="<?php echo $w->id; ?>" <?php if($filter == $w->id) { echo "selected"; } ?>><?php echo $w->category_name; ?></option>
                                           
                                        <?php } ?>
                                    </select>    
                                </form>
                                
                                
                            <h4 class="my-section-heading">
                                TMPT Workouts
                            </h4>
                            
                        </div>
                    </div>
                    
                    
                <?php echo $session->message(); ?>
            
            <?php if($workouts) { ?>
            
            <?php foreach($workouts as $x) : ?>
                <a href="completing_workout.php?id=<?php echo $session->user_id;?>&workout_id=<?php echo $x->id; ?>&exercise=1&set=1">
                    <div class="row program-row" style="background-image: url('img/<?php echo $x->workout_image; ?>');">
                        <div class="col-sm-12">
                            <div class="row workout-details-tmpt-workouts text-center">
                                <?php echo $x->workout_name; ?>
                            </div>
                        </div>
                    </div>
                </a>
            
            <?php endforeach; ?>
            
            <?php } else { ?>
                <div class="row program-row" style="background-image: url('img/<?php echo $x->workout_image; ?>');">
                        <div class="col-sm-12">
                            <div class="row workout-details-tmpt-workouts text-center">
                                NO WORKOUTS
                            </div>
                        </div>
                    </div>
            <?php } ?>
                </div>
            </div>







