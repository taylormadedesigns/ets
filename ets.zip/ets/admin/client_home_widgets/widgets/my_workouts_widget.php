<?php
    
    $user = User::find_by_id($session->user_id);
    $stat = Stats::find_all();

?>

<?php $workouts = Workouts::find_with_condition("WHERE client_id = {$session->user_id} AND studio_id = 1 AND active = 1"); ?>          
           
<div class="content-section-b">
    <div class="container"> 
        <div class="row">
            <div class="col-xs-12">
                <h4 class="my-section-heading">My Workouts</h4>
            </div>
        </div>           
<?php if($workouts) { ?>

            
                    
                    
            <?php foreach($workouts as $x) : ?>
                <a href="completing_workout.php?workout_id=<?php echo $x->id; ?>">
                    <div class="row program-row">
                        <div class="col-xs-3 col-sm-2 workout-image">
                            <img src="http://placehold.it/350" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-xs-9 col-sm-10">
                            <div class="row workout-details">
                                WORKOUT NAME: <?php echo $x->workout_name; ?>
                            </div>
                        </div>
                    </div>
                </a>
            
            <?php endforeach; ?>
                

<?php } else { ?>
    
    <div class="alert alert-danger">
        <span class="text-center">
            <p><b>No Workouts Set</b></p>
            <p>Your trainer is working on your new program. Please message them to let them know you have completed your current program.</p>
            <p><br><a href="" class="btn btn-danger">Request new program</a></p>
        </span>
    </div>

    
<?php } ?>

    </div>
</div>




