<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {
 
    $user           = User::find_by_id($session->user_id);
    $newsfeed       = Newsfeed::find_all($session->studio_id);
    
}
?>
<?php 
    if(isset($_POST['submit'])){
        if(!empty($_POST['status'])){
            $newsfeeds = new Newsfeed();
            $newsfeeds->studio_id    = $session->studio_id;
            $newsfeeds->user_id      = $session->user_id;
            $newsfeeds->post         = $_POST['status'];
            $newsfeeds->active       = 1;
            $newsfeeds->updated      = date('Y-m-d H:i:s');
            $newsfeeds->save();
            redirect('newsfeed.php');  
        } else {
            $session->message('<div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Oops... You forgot to write something.</div>');
            redirect('newsfeed.php');
        }
        
    }
?>
<!--    <a name="about"></a>--> 
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <div class="content-section-newsfeed">    
                <div class="container">    
                    <h4 class="my-section-heading">Newsfeed</h4>
                    <div class="col-xs-12">
                        <?php echo $session->message();?>
                        <form action="" method="post">
                            <div class="form-group">
                                <textarea type="text" name="status" class="form-control status" placeholder="What's on your mind?"></textarea>  
                            </div>
                            <div class="form-group pull-right">
                                <input type="submit" name="submit" class="btn btn-default" value="Post"> 
                            </div>
                        </form>
                    </div>
                </div> 
            </div> 
             
          <?php foreach ($newsfeed as $news) { ?>
          
          <?php $post_user = User::find_by_id($news->user_id); ?>
          <div id="<?php echo $news->id; ?>" class="content-section-blog">    
                <div class="container">             
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="newsfeed-profile-pic" style="background: url(<?php echo $post_user->admin == 1 ? "../admin/img/profile_pics/" . $post_user->id . "/" . $post_user->user_image : "../clients/img/profile_pics/" . $post_user->id . "/" . $post_user->user_image; ?>) 50% 50% no-repeat; background-size: cover;"></div><b><?php echo $post_user->first_name; ?></b> <i><?php echo date('d/m/y h:i A', strtotime($news->updated)); ?></i>
                            
                            
                            <?php $post = Newsfeed::find_by_id($news->id, $session->user_id); ?>
                            <?php if($post) { ?>
                                <div class="dropdown pull-right">
                                    <span class="dropdown-toggle" id="post_edit_toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        <span class="glyphicon glyphicon-option-horizontal pull-right edit_post"></span> 
                                    </span>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="post_edit_toggle">
<!--
                                        <li>
                                            <a href="newsfeed_edit_post.php?post_id=<?php echo $news->id;?>">Edit Post</a>
                                        </li>
                                        <li role="separator" class="divider"></li>
-->
                                        <li>
                                            <a href="newsfeed_delete_post.php?post_id=<?php echo $news->id;?>">Delete Post</a>
                                        </li>
                                    </ul>
                                </div>
                            
                            <?php } ?>
                            
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 post-text">
                           <?php echo $news->post; ?>
                        </div>   
                    </div>
                    <?php $total_likes = Newsfeed_likes::find_by_post_id($news->id); ?>
                    <?php $total_comments = Newsfeed_comments::find_by_post_id($news->id); ?>
                    
                  <?php if($total_likes || $total_comments){ ?>
                    <div class="row">
                        
                        <div class="col-xs-12 font-sm grey">
                            <?php if($total_likes) { ?>
                            <?php echo $total_likes == 1 ? $total_likes . " like" : $total_likes . " likes"; ?>
                            <?php } ?>
                
<!-- Activate to display total comments
                            <?php if($total_comments) { ?>
                            <?php echo $total_comments == 1 ? $total_comments . " comment" : $total_comments . " comments"; ?>
                            <?php } ?>
-->
                
                        </div>
                        
                    </div> 
                    <?php }   ?>
                   
                    <?php $liked = Newsfeed_likes::find_by_id($news->id,$session->user_id); ?>
                    <?php $comment = Newsfeed_comments::find_by_id($news->id,$session->user_id); ?>
                    
       
                    
                    <div class="row">
                       
                        
                        <?php echo $liked ? "<a href='newsfeed_unlike_post.php?id={$session->user_id}&post_id={$news->id}' class='post-like-btn liked'><i class='fa fa-thumbs-up'> Like</i></a>" : "<a href='newsfeed_like_post.php?id={$session->user_id}&post_id={$news->id}' class='post-like-btn'><i class='fa fa-thumbs-up'> Like</i></a>";?>
                        
<!--  Activate for a comment button - adding comments still need to be coded                      
                     <?php echo $comment ? "<a href='?id={$session->user_id}&post_id={$news->id}' class='post-like-btn liked'><i class='fa fa-comment'> Comment</i></a>" : "<a href='.php?id={$session->user_id}&post_id={$news->id}' class='post-like-btn'><i class='fa fa-comment'> Comment</i></a>";?>
-->
                      
                    </div> 
                    <!--- activate when wanting to see commnts --->
<!--
                    <?php $post_comments = Newsfeed_comments::find_all_post_comments($news->id); ?>
                    <?php if($post_comments) { ?>
                        <?php foreach($post_comments as $t) { ?>
                        
                    <div class="row">
                        <div class="col-xs-6 col-sm-offset-3">
                           <?php echo $t->post_comment; ?> 
                        </div>
                    </div>    
    
                        <?php } ?>
                    <?php } ?>     
-->
                    
                </div>
            </div>

            <?php } ?> 
            
                
            
            <?php include('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
