<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(!isset($session->user_id)){
    redirect("index.php");
} else {    
    $user = User::find_by_id($session->user_id);  
}

    if(isset($_POST['update_user'])){

        if($user) {
            
            $user->username = $_POST['username'];
            $user->first_name = $_POST['first_name'];
            $user->last_name = $_POST['last_name'];
            $user->day = $_POST['day'];
            $user->month = $_POST['month'];
            $user->year = $_POST['year'];
            $user->password = $_POST['password'];
            
            if(empty($_FILES['user_image']['tmp_name'])) {
                $user->save();
                $session->message("<div id='my-alert' class='alert alert-success alert-dismissible'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div>");
                redirect("my_profile.php");
                
            } else {
                $user->unlink_photo();
                $user->set_file($_FILES['user_image']);
                $user->upload_photo();
                $user->save();
                $session->message("<div id='my-alert' class='alert alert-success alert-dismissible'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div>");
//                redirect("edit_user.php?id={$user->id}");
                redirect("my_profile.php");
                
            }
            
        }
    
    }
//$users = user::find_all(); 
?>




<!--    <a name="about"></a>-->
   
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
        
<?php include ("includes/sub-navbar.php"); ?>
           
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                        <form action="" method="post" enctype="multipart/form-data"> 
                            <div class="col-xs-12">
                                <h4 class="my-section-heading">My Profile</h4>
                            </div>
                            <div class="col-xs-12 col-sm-4 text-center">
                                <div class="col-xs-4 col-xs-offset-4 col-sm-12 col-sm-offset-0">
                                    <img class="thumbnail" src="<?php echo $user->image_path_and_placeholder();?>" alt="" width="100%" >
                                    <input type="file" name="user_image">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-8">
                                <?php echo $session->message(); ?>
                                <div class="form-group">
                                    <label for="first_name">First Name:</label>
                                    <input type="text" class="form-control" name="first_name" value="<?php echo $user_id->first_name;?>">
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name:</label>
                                    <input type="text" class="form-control" name="last_name" value="<?php echo $user_id->last_name;?>">
                                </div>
                                <div class="form-group">
                                    <label for="dob">DOB:</label>
                                    <div class="row">
                                        <div class="col-xs-4">
                                        
                                            <select class="form-control" name="day">
<?php for($x=1; $x < 32; $x++) { ?>
                                                <option value='<?php echo $x; ?>' <?php if($x == $user->day){echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                        </div>
                                        <div class="col-xs-4">
                                            <select class="form-control" name="month">
<?php for($x=1; $x < 13; $x++) { ?>
                                                <option value='<?php echo $x; ?>' <?php if($x == $user->month){echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                        </div>
                                        <div class="col-xs-4">
                                        
                                            <select class="form-control" name="year">
<?php 
echo $today = date('Y');
for($x = 1901; $x <= $today; $x++) {
?>
                                                <option value="<?php echo $x; ?>" <?php if($user->year == $x) {echo "selected";}?>><?php echo $x; ?></option>
<?php } ?>
                                            </select>   
                                     
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="username">Username/Email</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo $user_id->username;?>">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" name="password" value="<?php echo $user_id->password;?>" >
                                </div>
                                <div class="form-group pull-right">
                                    <input type="submit" class="btn btn-primary" name="update_user" value="Update">
                                </div>
                            </div>
                        </form>
<!--
                        <div class="col-xs-12 col-sm-4 text-center">
                            <h4>Latest Activity</h4>
                        </div>
-->
                    </div>
                </div>
            </div>
            <?php include('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
