<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<?php 
if(isset($_GET['post_id'])){

    
}

?>