<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>
<!--    <a name="about"></a>-->
   
   
    <div id="wrapper">
        <?php include('includes/side_nav.php'); ?>
        <!-- /#sidebar-wrapper -->
<?php include('includes/navbar.php'); ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
           

           
            <div class="content-section-b">
                <div class="container">
                    <div class="row">
                      
                       <?php echo $session->message(); ?>
                       
                        <div class="col-xs-12">
                            <h4 class="my-section-heading text-center">Active Clients</h4>
                            <?php $active_users = User::find_all_active_clients($session->studio_id); 
                            foreach ($active_users as $au) { ?>
                                <a href="client_home.php?client_id=<?php echo $au->id . "&trainer_id=" . $session->user_id; ?>" class="mya">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <?php echo ucfirst($au->first_name) . " " . ucfirst($au->last_name); ?>
                                        <span class="font-xs"><?php echo "@" . $au->username; ?></span>
                                        <span class="pull-right">
                                            <?php echo $au->active ? "<span class='label label-success'>Active</span>" : "<span class='label label-danger'>Not Active</span> <span class='label label-primary'>Activate</span>"; ?>   
                                        </span>
                                    </div>
                                </div>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
       
       
        <?php 
        //include('old_content.php'); 
        ?>

            <a  name="contact"></a>
            <div class="footer-banner">

                <div class="container">

                    <div class="row">
                        <div class="col-lg-4">
                            <h2>Connect with us:</h2>
                        </div>
                        <div class="col-lg-8">
                            <ul class="list-inline banner-social-buttons">
                                <li>
                                        <a href="https://instagram.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-instagram fa-fw"></i> <span class="network-name">Instagram</span></a>
                                    </li>
                                    <li>
                                        <a href="https://facebook.com/taylormadepersonaltraining" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                                    </li>
                                    <li>
                                        <a href="https://au.linkedin.com/in/taylor-made-pt-bb467542" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>
                                    </li>
                            </ul>
                        </div>
                    </div>

                </div>
                <!-- /.container -->
            </div>
            <!-- /.banner -->

    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
            
            
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
        
        
    
    
