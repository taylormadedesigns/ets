<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/navbar.php'); ?>
  
<!-- Page Content -->
<div class="banner">

        <div class="container">

            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>TERMS & CONDITIONS</h2>
                </div>
                <div class="col-lg-8">
                    
                </div>
            </div>

        </div>
        <!-- /.container -->
</div>
    <!-- /.banner -->
            
<div class="content-section-b">
    <div class="container">
        <div class="row">

            Terms and Conditions

PURCHASING AGREEMENT

1.         PREAMBLE

The following provides the terms, policies, procedures and conditions to be adhered to by the parties in the Purchase of the Program. 

By purchasing the Program the Purchaser agrees to all of the following terms and conditions, subject to the rights granted to the Purchaser by statutory consumer protection legislation, which cannot be excluded, due to the nature of the Program and/or the products and services offered by Evennett.

The Purchase of the Programs is subject to the following terms and conditions. Customers are advised to review these terms and conditions carefully before making the Purchase.

2.         DEFINITIONS

2.1      For the purpose of this Agreement these following definitions apply;

(a)       “Evennett” refers to the author of the Programs, Scott Evennett as well as Evennett Pty Ltd and its Affiliates;

(b)       “Purchaser” refers to those seeking to purchase the Programs and those who have purchased the Programs and who by purchasing, accepts these terms and conditions;

(c)        “Program (A)” refers to the individual designed program;

(d)       “Program (B)” refers to the generic program;

(e)       “Program” refers to either Program (A), Program (B) or both;

(f)         “Affiliates” refers to any of Evennett’s associated entities defined in the Corporations Act 2001 (Cth);

(g)       “Intellectual Property” refers to all of Evennett’s proprietary rights and interests including but not limited to copyright, trademarks, designs, patents, character names, writings, digital content, business names, inventions, ideas, symbols, artwork, confidential information and moral rights as defined in the Copyright Act 1966 (Cth).

(h)       “Medical Practitioners” refers to “a person whose primary employment role is to diagnose physical and mental illnesses, disorders and injuries and prescribe medications and treatments that promote or restore good health” defined by the Australian Institute of Health and Welfare.

3.         ELIGIBILITY

3.1.     The Purchaser guarantees that they are the age of 15 or over.

3.2.     Purchasers between the ages of 15–17 seeking to purchase Program (A) must be entered into the purchase by their Parent or Guardian.

3.3.     Purchasers between the ages of 15–17 seeking to Purchase Program (A) without being entered into the Purchase by their Parent or Guardian will not be delivered the Program.

3.4.     Parents or Guardians of Purchasers between the ages of 15–17 acknowledge that by entering into the Purchase on behalf of the Purchaser, that they understand this agreement and give consent for the Purchaser to undertake the activities stipulated in the Program.

4.         MEDICAL AND NUTRITIONAL DISCLAIMER

4.1.     Evennett are not medical practitioners and as such Evennett does not and cannot provide the Purchaser with medical assistance in any form. The Purchaser is solely responsible for their health and wellbeing and Evennett encourages the Purchaser to seek out qualified medical advice prior to purchasing the Program. The Program does not contain medical advice or assistance and should not be interpreted as medical advice or assistance.

4.2.     By purchasing the Program the Purchaser acknowledges that Evennett and its affiliates have not provided medical advice and the use of such programs are at the sole risk of the purchaser. 

4.3.     Evennett is not an accredited Nutritionist or Dietician, however the Program has been designed strictly on the advice of an accredited nutritionist and dietician pursuant to the NSW Fitness Industry Code of Practice.

4.4.     By purchasing the Program the Purchaser acknowledges clause 4.3 and also accepts that it is the sole responsibility of the Purchaser for any individual dietary requirements to be adhered to by the Purchaser.

4.5.     Evennett advises that the Program is not suited for people with serious medical conditions, minors under the age of 15 and is not formulated to provide adequate nutrition for pregnant women.

5.         NON-DISTRIBUTION

5.1.     The Program is the Intellectual Property of Evennett. Evennett does not give the Purchaser permission for the distribution of the Program of any kind without the express consent of Evennett. To do so would be a violation of Evennett’s proprietary rights pursuant to the Copyright Act 1966 (Cth), Trade Marks Act 1995 (Cth), Designs Act 2003 (Cth) and Patents Act 1990 (Cth).

5.2.     By purchasing the Program the Purchaser acknowledges that if they are found to violate Evennett’s proprietary rights, Evennett may seek appropriate damages resultant from the violation.

6.         PAYMENT POLICY

6.1.     By purchasing the Program ("the Purchase") the Purchaser agrees to:

(a)       pay using a valid credit card (or other form of payment as Evennett may allow);

(b)       provide Evennett with current and complete information as detailed in the purchase order form including full legal name, street address, telephone number, email address, credit card details and billing information as required and without limiting any of Evennett’s rights and remedies if it is discovered or believed that any information provided by the Purchaser is inaccurate or not complete;

(c)       pay all costs, fees, charges, applicable taxes and other charges as may be incurred in respect of the Purchase ("the Costs"); and

(d)       pay the Costs in Australian Dollars (AUD $) unless otherwise indicated.

(e)       pay for the Program, fully acknowledging that Evennett strictly enforces a ‘no refund’ policy on its Program.

6.2.     Payment Policy for Program (A)

6.2.1.      The Purchaser may make payment upfront to Evennett on the Purchase of Program (A).

6.2.2.      On upfront payment of Program (A) the Purchaser will be provided with the full 12 week program. 

6.2.3.      Payment may alternatively be made by direct debit in 3 separate and equal installments (“Installment Structure”) over 12 weeks.

6.2.4.      An installment will be debited immediately on the Purchase of Program (A) (“Purchase Date”). A second installment will be debited after a period of four (4) weeks after the Purchase Date. The final installment will be debited after another period of four (4) weeks after the Second installment was debited.

6.2.5.      By opting for the Installment Structure in the Purchase of Program (A), the Purchaser accepts that they will be provided with one third of the program immediately after each direct debit accumulating to the full 12 week program on the accumulated full payment of Program (A).

6.2.6.      The Installment Structure may only be varied on written agreement between the Purchaser and Evennett. 

6.2.7.      By opting for the Installment Structure in the Purchase of Program (A) the Purchaser accepts to be bound by the Installment Structure until the end of the 12 weeks.

6.3.     Payment Policy for Program (B)

6.3.1.      The Purchaser must make payment upfront to Evennett on the Purchase of the Program (B).

6.3.2.      On full payment of Program (B) the Purchaser will then receive Program (B).

7.         UPGRADE PROCEDURE

7.1.     If the Purchaser wishes to upgrade their Purchase from Program (B) to Program (A) then the Purchaser agrees to:

(a)       pay Evennett the Purchase price of Program (A) upfront; or

(b)       pay Evennett the first payment of the Installment Structure and then be bound by the payment policy for Program (A) stipulated in (Paragraph 6.2.4.) from the time of upgrade onwards.

7.2.     Any payments made from Program (B) will not be credited to the Purchase of Program (A).

7.3.     The same policy applies for Purchasers wishing to exchange policies from Program (A) to Program (B).

8.         INDEMNITY

8.1.      The Purchaser agrees to indemnify Evennett to the full extent needed from any and all third party claims, liabilities, costs, expenses including solicitor/client costs on an indemnity basis, that Evennett may incur or suffer as a result of the Purchasers improper or illegal use of the Program and/or from the Purchasers breach of any of the Terms and Conditions and/or any facilitation or support by the Purchaser of a third party causing any loss or damage to Evennett.

8.2.     The Purchaser agrees to indemnify Evennett for any claims, losses, liabilities, costs or expenses ("Losses") incurred by Evennett, that the Purchaser may cause, or contribute to.

9.         DELIVERY

9.1.     The delivery of the Program is strictly based online.

9.2.     The Purchaser will receive the Program by email, to the email address stipulated in the payment instructions (pursuant to paragraph 6.1(b)).

9.3.     The Program will only be sent to the one nominated email address.

9.4.     If the Purchaser has not received the Program to the stipulated email address after payment or installment, then the Purchaser may email Evennett on info@evennett.com.au and provide details as to why they may have not received the Program.

9.5.     By purchasing the Program the Purchaser accepts that it is at Evennett’s discretion to accept the details that the Purchaser has provided and then re-send the Program to the amended email address.

10.      NO GUARANTEE

10.1. By purchasing the Program the Purchaser accepts that the outcome of using the Program is solely dependent on the Purchaser.

10.2. Subject to the rights granted to you by statutory consumer protection legislation, which cannot be excluded, due to the nature of the Program and/or the products and services offered by Evennett, the Purchaser accepts that Evennett does not guarantee its results and does not purport to guarantee its results.

11.      NON INCLUSION

11.1. By purchasing the Program the Purchaser accepts that the Program is limited to meal plans, exercise regimes and other activities stipulated throughout the particulars of the Program.

11.2. The Purchaser accepts all foods stipulated throughout the Program is not included as part of the Purchase. The Purchaser accepts that all foods must be independently sourced by the Purchaser.
AUSTRALIAN SPORTS NUTRITION DISCLAIMER/NO WARRANTY

Australian Sports Nutrition Pty Ltd provides www.asn.com.au and its contents on an "as is" basis. Australian Sports Nutrition Pty Ltd and its officers, directors, employees, agents, licensors, suppliers, content providers and the like (together, "affiliates") make no representations or warranties of any kind, express or implied, with respect to this site or its contents, including without limitation the products, information or services offered or sold on or through this site or any other site to which this site links (each a "Linked Site") and the uninterrupted and error-free use of this site.

Australian Sports Nutrition Pty Ltd and its affiliates expressly disclaim all such representations and warranties, including without limitation all warranties of merchantability, accuracy, timeliness, completeness, fitness for a particular purpose and non-infringement. Australian Sports Nutrition Pty Ltd and its affiliates do not warrant that the site or files available on the site will be free from corrupted data, computer viruses or similar destructive or contaminating code. No oral or written statements by Australian Sports Nutrition Pty Ltd or its affiliates will create any warranty not expressly set forth herein. Your use of this site and any linked site is at your own risk and understanding of the above.

The products, information, services and other content provided on and through this site, including without limitation any products, information, e-mails, facsimiles, services and other content provided on any Linked Site, are provided for informational purposes only to facilitate discussions with a healthcare professional regarding treatment. The information provided on this site and Linked Sites, including without limitation information relating to medical and health conditions, products and treatments, is often provided in summary or aggregate form. It is not intended as a substitute for advice from your physician or other healthcare professional or any information contained on or in any product label or packaging. Before buying or using any products, information or services provided on or through this site, including without limitation any products, information or services provided on any Linked Site, you should speak with a healthcare professional.

You should not use the information on this site for diagnosis or treatment of any health problem or for prescription of any medication or other treatment. You should always speak with your physician or other healthcare professional, and carefully read all information provided by the manufacturer of a product and on or in any product label or packaging, before taking any medication or nutritional, herbal or homeopathic supplement, before starting any diet or exercise program or before adopting any treatment for a health problem. Each person is different, and the way you react to a particular product may be significantly different from the way other people react to such product.

Unless otherwise indicated on this site, Australian Sports Nutrition Pty Ltd does not endorse any specific product or service offered, advertised or sold on or through this site, including without limitation any product or service offered, advertised or sold on or through any Linked Site. Australian Sports Nutrition Pty Ltd is not responsible for any product or service sold on or through this site or any claims of quality or performance made on or through this site, including any claims of quality or performance made on or through any Linked Site. You are advised that other sites on the Internet, including without limitation Linked Sites and sites that link to this site, might contain material or information that some people may find offensive or inappropriate; or that is inaccurate, untrue, misleading or deceptive; or that is defamatory, libellous, infringing of others' rights or otherwise unlawful. Australian Sports Nutrition Pty Ltd expressly disclaims any responsibility for the content, legality, decency or accuracy of any information, and for any products and services, that appear on any Linked Site or any site that links to this site.

Price and availability information on this site is subject to change without notice.

LIMITATION OF LIABILITY

Australian Sports Nutrition Pty Ltd and its affiliates shall not under any circumstances be liable for any damages of any kind arising out of, in connection with or relating to the use of or inability to use this site, including without limitation any liability (i) as a publisher of information, (ii) as a reseller of any products or services, (iii) for any defective products, (iv) for any incorrect or inaccurate information, (v) for any unauthorized access to or disclosure of your transmissions or data, (vi) for statements or conduct of any third party on the site, or (vii) for any other matter relating to this site or any linked site. This is a comprehensive limitation of liability that applies to all damages of any kind, including without limitation any direct, indirect, special, incidental or consequential damages (including without limitation damages for loss of business, loss of profits, loss of good will, loss of use, loss of data, cost of procuring substitute goods, services or information, litigation or the like), whether based on breach of contract, breach of warranty, tort (including without limitation negligence), product liability or otherwise, even if the user advises of the possibility of such damages. The limitations of liability set forth herein are fundamental elements of the basis of the bargain between Australian Sports Nutrition Pty Ltd and the user. The products, information and services offered on and through this site would not be provided without such limitations. Because the laws of some states may not allow for the exclusion of certain damages, in such states liability is limited to the fullest extent permitted by law.

Notwithstanding the foregoing, the sole and entire maximum liability of Australian Sports Nutrition Pty Ltd and its affiliates for any reason, and your sole and exclusive remedy for any cause or claim whatsoever, shall be limited to the amount paid by you for any product, information or service purchased by you from Australian Sports Nutrition Pty Ltd on this site.

You agree to indemnify, defend and hold harmless Australian Sports Nutrition Pty Ltd and its affiliates against all claims, demands, causes of action, losses, expenses, damages and costs, including without limitation any reasonable solicitors fees, resulting or arising from or relating to your use of or conduct on the site, any activity related to your account by you or any other person, any material that you submit to, post on or transmit through the site, your violation of these Terms of Use, your infringement or violation of any rights of another, or termination of your access to this site.

All products and services offered on or through this site are provided subject to any applicable tariffs and any accompanying terms and conditions.

PRIVACY AND CHILD PROTECTION

Australian Sports Nutrition Pty Ltd respects the privacy of its users in accordance with the terms of Australian Sports Nutrition Pty Ltd Privacy and Child Protection Policy. Australian Sports Nutrition reserves the right to monitor www.asn.com.au and to disclose any information recorded or posted on, submitted to or transmitted through the site to the extent, in its sole discretion, deems such disclosure necessary or appropriate (i) to comply with any law, regulation, subpoena or government request, (ii) to operate the site, or (iii) to protect the rights or property of Australian Sports Nutrition Pty Ltd or its affiliates.

YOUR USAGE OF SITE; TERMINATION OF USAGE

You agree to maintain the security of your account on the site, including the security of your password and other confidential information relating to the use of the site and your account on the site. You agree to be responsible for all charges resulting from the use of your account on the site, including charges resulting from unauthorized use of your account prior to your taking steps to prevent such occurrence by changing your password and notifying Australian Sports Nutrition Pty Ltd.

You agree to use this site only for lawful purposes, and that you are responsible for your use of and communications on the site. You agree not to post on or transmit through this site any unlawful, infringing, threatening, harassing, defamatory, vulgar, obscene, profane, indecent, offensive, hateful or otherwise objectionable material of any kind, including without limitation any material that encourages criminal conduct or conduct that would give rise to civil liability, infringes others' intellectual property rights or otherwise violates any applicable local, state, national or international law. You agree not to use this site in any manner that interferes with its normal operation or with any other user's use and enjoyment of the site. You agree not to reproduce, modify, distribute, replicate, commercially exploit or create derivative works of any portion of the site or material thereon.

You further agree that you will not access by any means except through the interface provided by Australian Sports Nutrition Pty Ltd for access to the site. You agree that you will not access this site from any territory where its contents are illegal, and that you, and not Australian Sports Nutrition Pty Ltd and its affiliates, are responsible for compliance with applicable local laws.

You agree that Australian Sports Nutrition Pty Ltd may terminate or suspend your access to all or part of this site, without notice, for any conduct that Australian Sports Nutrition Pty Ltd, in its sole discretion, believes is in violation of these Terms of Use or any applicable law or is harmful to the interests of another user, Australian Sports Nutrition Pty Ltd or its affiliates.

USAGE BY MINORS

Because of the nature of the World Wide Web, Australian Sports Nutrition Pty Ltd cannot prohibit minors from visiting this site. Australian Sports Nutrition Pty Ltd must rely on parents, guardians and those responsible for supervising children and teenagers to decide which materials are appropriate for such children and teenagers to view and/or purchase. Australian Sports Nutrition Pty Ltd requires that (i) all purchases on the site be made by adults 18 years of age or older, and (ii) all users who provide personal information to Australian Sports Nutrition Pty Ltd be 18 years of age or older, or, if under 18, that such information be accompanied by verifiable parental consent as further set forth in our Privacy and Child Protection Policy.

APPLICABLE LAW; JURISDICTION

This agreement shall be governed by and construed in accordance with the laws of the State of New South Wales without regard to choice of law rules. Each user agrees to submit to personal jurisdiction in the State of New South Wales and further agrees that any cause of action arising from or relating to the use of this site or this agreement shall be brought exclusively in a court in New South Wales.

SEVERABILITY; INTERPRETATION

If any provision of this agreement shall be deemed unlawful, void or for any reason unenforceable by a court of competent jurisdiction, the validity and enforceability of any remaining provisions shall not be affected. When used in this agreement, the term "including" shall be deemed to be followed by the words "without limitation."

ENTIRE AGREEMENT; AMENDMENTS

This agreement constitutes the entire and only agreement between Australian Sports Nutrition Pty Ltd and each user of this site with respect to the subject matter of this agreement and supersedes any and all prior or contemporaneous agreements, representations, warranties and understandings, written or oral, with respect to the subject matter of this agreement. You agree to review this agreement prior to your use of this site and your use of this site shall be deemed acceptance of and assent to this agreement by you. Australian Sports Nutrition Pty Ltd may, in its sole discretion, amend this Terms of Use agreement from time to time.

MISCELLANEOUS

The failure of Australian Sports Nutrition Pty Ltd or its affiliates to insist upon strict adherence to any term of this agreement shall not constitute a waiver of such term and shall not be considered a waiver or limit that party's right thereafter to insist upon strict adherence to that term or any other term of this agreement. You agree that regardless of any statute or law to the contrary, any claim of cause of action arising from or relating to use of this site or this agreement must be filed within one (1) year after such claim or cause of action arose, or will be forever barred. The "No Warranty; Disclaimer" and "Limitation of Liability" provisions of this agreement are for the benefit of Australian Sports Nutrition Pty Ltd and its affiliates as defined herein, and each of these individuals or entities shall have the right to assert and enforce these provisions directly against you on its own behalf.

PRIVACY AND CHILD PROTECTION POLICY

Australian Sports Nutrition Pty Ltd cares about the privacy of each user of its Web site ("user" or "you"), including those who trust us enough to place orders. In order to protect the privacy of its users, Australian Sports Nutrition Pty Ltd has adopted the following policy:

I. General Information

When you use the Web site some basic general information is collected. This information is used to improve the Web site and make your use of the Web site as enjoyable and efficient as possible.

This general information is used internally in connection with Australian Sports Nutrition Pty Ltd business, including Australian Sports Nutrition Pty Ltd personal, marketing and advertising efforts.

II. Personal Information

When you set up an account on the Web site or purchase an item from the Web site, we collect personal information (which you provide) that may include your: (i) first and last name; (ii) billing address; (iii) shipping address; (iv) other shipping addresses; (v) email address; (vi) phone number; (vii) credit card account number; (viii) items purchased from us; and (ix) browsing, buying and selling patterns (collectively, "Personal Information").

III. Use/Sharing of Personal Information

Your name, shipping and billing addresses, and credit card number(s) are used by Australian Sports Nutrition Pty Ltd in order to provide you with the goods that you purchase on the Web site. We use your email address to provide you with information about your order and its status, and we may occasionally send out emails, including newsletters, to people who have placed an order online.

Your phone number is used by Australian Sports Nutrition Pty Ltd in the event that our representatives need to contact you about an order you have placed. It is also used when marking packages for delivery; to ensure you are contactable by our delivery service should delivery difficulties be experienced.

Personal Information is used internally in connection with Australian Sports Nutrition Pty Ltd business, including Australian Sports Nutrition Pty Ltd promotional, marketing and advertising efforts, in a manner which does not readily identify a user to any third party.

PLATINUM MEMBERS

Platinum club discounts and promotional items are only useable in-store and by the sole owner of the key-ring. Ownership, prizes and product specials may not be transferred to third parties unless otherwise authorised by ASN management.

CREDIT CARD SECURITY

The Internet is a vast network of computers. Because the data passes from computer to computer, some Internet shoppers worry that unauthorized persons may intercept the data and gain access to credit card numbers, but shopping on a secure site is actually safer than handing a credit card to a waiter in a restaurant. Taking the steps below will lower the chances of interception of your credit card number:

•  Limit your online shopping to Internet merchants, such as Australian Sports Nutrition Pty Ltd, with sites equipped with Secure Sockets Layer (SSL) technology. SSL prevents unauthorized people from intercepting your data.

•  Use a browser, such as Netscape Navigator or Internet Explorer, which supports SSL. These browsers show a symbol in the status bar, such as a key or lock, when you are on a site that uses SSL. Most banks will cover the cost of fraud resulting from unauthorized use of your credit card or may limit your liability.

•  Credit card information collected by Australian Sports Nutrition Pty Ltd is encrypted through Secure Sockets Layer before it is transmitted over the Internet.

Australian Sports Nutrition Pty Ltd fully cooperates with law agencies in identifying those who use our services for illegal activities, and may in its sole discretion disclose Personal Information or other information to satisfy any law, regulation, subpoena, or government request. Australian Sports Nutrition Pty Ltd reserves the right to release Personal Information or other information about users who we believe are engaged in illegal activities or are otherwise in violation of our Terms of Use, even without a subpoena, warrant or court order, if we believe in our sole discretion that such disclosure is necessary or appropriate to operate the Web site, or to protect the rights or property of Australian Sports Nutrition Pty Ltd, its affiliates, or any of their officers, directors, or employees, agents, third-party content providers, suppliers, sponsors, or licensors. Australian Sports Nutrition Pty Ltd also reserves the right to report to law enforcement agencies any activities we reasonably believe in our sole discretion to be unlawful.

IV. Collecting Information From Children Younger than 16

Australian Sports Nutrition Pty Ltd does not knowingly collect or use any Personal Information from children younger than 16 years of age without obtaining verifiable parental consent.

V. Miscellaneous

Australian Sports Nutrition Pty Ltd wants you to be aware that when you click on links (including advertising banners), which take you to third-party Web sites, you will be subject to such third parties' privacy policies. While we support the protection of privacy on the Internet, Australian Sports Nutrition Pty Ltd expressly disclaims any and all liability for the actions of third parties, including without limitation actions relating to the use and/or disclosure of Personal Information by third parties.

Our Privacy and Child Protection Policy is subject to change. In the event of any change, we will provide notice of such change on this page.

This disclaimer covers all material and information of all types in any and every part of this site and its attachments.
        </div>
    </div>
</div>
        </div>
            
    
    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
