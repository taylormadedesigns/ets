$(document).ready(function(){
  
    var url = $('iframe').attr('src');
    
    $('.stop-video').on("click" , function(){
        
        $('iframe').attr('src', url);
        
    });
    $('.play-button').on("click" , function () {
        
       
        $('iframe').attr('src', url + '&autoplay=1');
        
        
    });
    

       
   });

    