<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/navbar-fixed.php'); ?>
<!--    <a name="about"></a>-->
   
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="http://placehold.it/1800x600" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="http://placehold.it/1800x600" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="http://placehold.it/1800x600" alt="Third slide">
    </div>
  </div>
</div>
   
    <div class="module-a">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1>Fire Safety Consulting in Sydney, NSW and Throughout Australia</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam vero aliquid delectus laboriosam sunt voluptas, eligendi consectetur dolorem aliquam quam sint optio similique nobis, molestiae sapiente quia. Id, tempora, nostrum!</p>
                </div>
            </div>
        </div>
    </div>
        <!-- /.container -->
    <div class="module-image">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <div class="col" style="background-image: url('http://placehold.it/200'); background-size: cover; background-position: center; height: 200px;">

                    </div>
                    <div class="col learn-more-box-text">
                        Learn More 
                    </div>
                </div>
                <div class="col text-center">
                    <div class="col" style="background-image: url('http://placehold.it/200'); background-size: cover; background-position: center; height: 200px;">

                    </div>
                    <div class="col learn-more-box-text">
                        Learn More 
                    </div>
                </div>
                <div class="col text-center">
                    <div class="col" style="background-image: url('http://placehold.it/200'); background-size: cover; background-position: center; height: 200px;">

                    </div>
                    <div class="col learn-more-box-text">
                        Learn More 
                    </div>
                </div>
                <div class="col text-center">
                    <div class="col" style="background-image: url('http://placehold.it/200'); background-size: cover; background-position: center; height: 200px;">

                    </div>
                    <div class="col learn-more-box-text">
                        Learn More 
                    </div>
                </div>   
            </div>
        </div>
    </div>
    <div class="module-b">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class="white">ELITE FIRE TRAINING</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa quasi laboriosam rerum est aspernatur non autem error! Modi, accusamus doloribus molestias, mollitia velit officia ex voluptas omnis numquam, in dicta.</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="module-a">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1>Are you compliant?</h1>   
                </div>
            </div>
            <div class="row">
                <div class="col">
                    Is your business compliant?
                </div>
                <div class="col">
                    Is your business compliant?
                </div>
                <div class="col">
                    Is your business compliant?
                </div>
            </div>
        </div>
        <!-- /.container -->
    </div>

    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
