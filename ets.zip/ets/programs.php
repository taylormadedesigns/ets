<?php $title = "Home"; ?>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/navbar.php'); ?>
<!--    <a name="about"></a>-->
    <div class="program-header">
        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h2>FINR YOUR</h2>
                        <hr class="intro-divider">
                        <h1> PERFECT PROGRAM</h1>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->
    <div class="content-section-b">
        <div class="container">
            <div class="row">
                <div class="program-heading-1">Fundamentals Program - <i>First week of all programs</i></div>
                <div class="hidden-xs col-sm-6"><img src="http://placehold.it/1000" width="100%"></div>
                <div class="col-sm-6 program-text">
                    <div class="program-subheading">
                        Who should do it?
                    </div>
                    <div class="program-content">
                        Everyone is required to start with a fundamentals program. 
                    </div>
                    <div class="program-subheading">
                        What is Fundamentals?
                    </div>
                    <div class="program-content">
                        <p>Fundamentals Program will give you the psycological and physical preparedness required to start your program.</p>
                        <p>You will be given all your exercises that are in your program so you can start to learn the movements. Your goals are set and your nutrition intake requirments calculated.</p>
                        <p></p>
                        <p>This week is all about preparing for success and learning the correct movements.</p>
                    </div>
                    <div class="program-subheading">
                        Is it mandatory?
                    </div>
                    <div class="program-content">
                        <p>Yes, fundamentals is mandatory.</p>
                        
                    </div>
                    <div class="program-footer">
                        <a href="" class="btn btn-default">Watch Video</a> <a href="" class="btn btn-default">Join Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-section-c">
        <div class="container">
            <div class="row">
                <div class="program-heading-2">Beginner Program</div>
                <div class="col-sm-6 program-text">
                    <div class="program-subheading">
                        Who should do it?
                    </div>
                    <div class="program-content">
                        Anyone who has not regularly trained within the last 6 months. 
                    </div>
                    <div class="program-subheading">
                        What are the benefits?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum quis accusantium sunt saepe soluta cupiditate, rem officia. Iusto unde eaque, cumque ipsa, quis ea laboriosam nam sed quidem ducimus beatae. 
                    </div>
                    <div class="program-subheading">
                        Is it mandatory?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus accusamus dolores in ratione delectus placeat error, iusto, suscipit saepe eveniet pariatur deleniti aspernatur. Pariatur eos temporibus odit facere, totam velit!
                    </div>
                    <div class="program-footer">
                        <a href="" class="btn btn-default">Watch Video</a> <a href="" class="btn btn-default">Join Now</a>
                    </div>
                </div>
                <div class="hidden-xs col-sm-6"><img src="http://placehold.it/1000" width="100%"></div>
            </div>
        </div>
    </div>
    <div class="content-section-b">
        <div class="container">
            <div class="row">
                <div class="program-heading-1">Intermediate Program</div>
                <div class="hidden-xs col-sm-6"><img src="http://placehold.it/1000" width="100%"></div>
                <div class="col-sm-6 program-text">
                    <div class="program-subheading">
                        Who should do it?
                    </div>
                    <div class="program-content">
                        Anyone who has been consistantly training for 3 to 24 months.
                    </div>
                    <div class="program-subheading">
                        What are the benefits?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum quis accusantium sunt saepe soluta cupiditate, rem officia. Iusto unde eaque, cumque ipsa, quis ea laboriosam nam sed quidem ducimus beatae. 
                    </div>
                    <div class="program-subheading">
                        Is it mandatory?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus accusamus dolores in ratione delectus placeat error, iusto, suscipit saepe eveniet pariatur deleniti aspernatur. Pariatur eos temporibus odit facere, totam velit! 
                    </div>
                    <div class="program-footer">
                        <a href="" class="btn btn-default">Watch Video</a> <a href="" class="btn btn-default">Join Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-section-c">
        <div class="container">
            <div class="row">
                <div class="program-heading-2">Advanced Program</div>
                <div class="col-sm-6 program-text">
                    <div class="program-subheading">
                        Who should do it?
                    </div>
                    <div class="program-content">
                        Anyone who has been training for over 24 months.
                    </div>
                    <div class="program-subheading">
                        What are the benefits?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum quis accusantium sunt saepe soluta cupiditate, rem officia. Iusto unde eaque, cumque ipsa, quis ea laboriosam nam sed quidem ducimus beatae. 
                    </div>
                    <div class="program-subheading">
                        Is it mandatory?
                    </div>
                    <div class="program-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus accusamus dolores in ratione delectus placeat error, iusto, suscipit saepe eveniet pariatur deleniti aspernatur. Pariatur eos temporibus odit facere, totam velit! 
                    </div>
                    <div class="program-footer">
                        <a href="" class="btn btn-default">Watch Video</a> <a href="" class="btn btn-default">Join Now</a>
                    </div>
                </div>
                <div class="hidden-xs col-sm-6"><img src="http://placehold.it/1000" width="100%"></div>
            </div>
        </div>
    </div>
    
    
    <div class="content-section-d">
        <div class="container">
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4 my-section-heading">What program is best for me?</div>
                <div class="col-xs-12 text-center">
                    <p>Unsure what program is best for you? Simple. Try our program builder.</p>
                    <br>
                    <p><a href="" class="btn btn-lg btn-default">Program Builder</a></p>
                </div>
            </div>
        </div>
    </div>
   

    <div class="content-section-c">
        <div class="container">
            <div class="col-xs-6 col-sm-5 col-sm-offset-1 price-panel text-center">
                <div class="highlights-heading">
                    Weekly
                </div>
                <div class="price-pre-header">
                    WEEKLY PAYMENTS OF
                </div>
                <div class="price-header">
                    $9.95
                </div>
                <div class="price-body">
                    PAY UPFRONT TO SAVE $39.35
                </div>
                <div class="price-footer">
                    <a href="" class="btn btn-lg btn-default">Join Now</a>
                </div> 
            </div>
            <div class="col-xs-6 col-sm-5 price-panel text-center">
                <div class="highlights-heading">
                    Upfront
                </div>
                <div class="price-pre-header">
                    EASY UPFRONT PAYMENT
                </div>
                <div class="price-header">
                    $99.95
                </div>
                <div class="price-body">
                    SAVING $39.35 EVERY 8 WEEKS
                </div>
                <div class="price-footer">
                    <a href="" class="btn btn-lg btn-default">Join Now</a>
                </div> 
            </div>
            <div class="col-xs-12 col-sm-10 col-sm-offset-1 price-panel text-center"><b>Cancel at anytime</b> - What have you got to lose?</div>
            
        </div>
    </div>
    
    <!--page content ---->
<?php 
//include('old_content.php'); 
?>

	<a  name="contact"></a>
    <div class="footer-banner">

        <div class="container">

            <div class="row">
                <div class="col-lg-4">
                    <h2>Connect with us:</h2>
                </div>
                <div class="col-lg-8">
                    <ul class="list-inline banner-social-buttons">
                        <li>
                                <a href="https://instagram.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-instagram fa-fw"></i> <span class="network-name">Instagram</span></a>
                            </li>
                            <li>
                                <a href="https://facebook.com/taylormadepersonaltraining" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">Facebook</span></a>
                            </li>
                            <li>
                                <a href="https://twitter.com/TaylorMadePT" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>
                            </li>
                            <li>
                                <a href="https://au.linkedin.com/in/taylor-made-pt-bb467542" target="_blank" class="btn btn-primary btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>
                            </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /.container -->
    </div>
    <!-- /.banner -->

    <!-- Footer -->
<?php require_once('includes/footer.php'); ?>
